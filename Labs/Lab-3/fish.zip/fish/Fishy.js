(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Fishy_atlas_", frames: [[0,703,505,226],[1494,698,504,227],[1499,467,503,229],[1499,235,501,230],[0,470,498,231],[500,469,494,232],[0,235,495,233],[1500,0,496,233],[500,0,497,233],[0,0,498,233],[999,0,499,232],[999,234,498,232],[497,235,497,232],[996,468,496,232],[996,702,493,231],[507,703,123,210]]}
];


// symbols:



(lib.CachedBmp_186 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_185 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_184 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_183 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_182 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_181 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_180 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_179 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_178 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_177 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_176 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_175 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_174 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_173 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_172 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_156 = function() {
	this.initialize(ss["Fishy_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Fishy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Armature_5
	this.instance = new lib.CachedBmp_172();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_173();
	this.instance_1.setTransform(-1.55,0.95,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_174();
	this.instance_2.setTransform(-2.2,2.55,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_175();
	this.instance_3.setTransform(-2.45,4.2,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_176();
	this.instance_4.setTransform(-2.2,5.8,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_177();
	this.instance_5.setTransform(-2.25,4.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_178();
	this.instance_6.setTransform(-2.15,3,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_179();
	this.instance_7.setTransform(-1.9,1.65,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_180();
	this.instance_8.setTransform(-1.45,0.3,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_181();
	this.instance_9.setTransform(-0.8,-0.95,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_182();
	this.instance_10.setTransform(-2.7,-0.55,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_183();
	this.instance_11.setTransform(-4.15,-0.25,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_184();
	this.instance_12.setTransform(-5.25,0.15,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_185();
	this.instance_13.setTransform(-5.95,0.6,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_186();
	this.instance_14.setTransform(-6.2,1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.2,-0.9,253.5,122.7);


// stage content:
(lib.Fishy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Fishy_1();
	this.instance.setTransform(422.95,102.5,0.7641,0.8112,-14.9966,0,0,122.9,57.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:120.6,regY:60.4,rotation:-14.9981,x:408.6,y:110.65},0).wait(1).to({x:395.3,y:115.95},0).wait(1).to({x:382.05,y:121.2},0).wait(1).to({x:368.75,y:126.5},0).wait(1).to({x:355.5,y:131.75},0).wait(1).to({x:342.2,y:137.05},0).wait(1).to({x:328.9,y:142.3},0).wait(1).to({x:315.65,y:147.6},0).wait(1).to({x:302.35,y:152.9},0).wait(1).to({x:289.1,y:158.15},0).wait(1).to({x:275.8,y:163.45},0).wait(1).to({x:262.55,y:168.7},0).wait(1).to({x:249.25,y:174},0).wait(1).to({x:235.95,y:179.25},0).wait(1).to({x:222.7,y:184.55},0).wait(1).to({x:209.4,y:189.85},0).wait(1).to({x:196.15,y:195.1},0).wait(1).to({x:182.85,y:200.4},0).wait(1).to({x:169.6,y:205.65},0).wait(1).to({x:156.3,y:210.95},0).wait(1).to({x:143.05,y:216.2},0).wait(1).to({x:129.75,y:221.5},0).wait(1).to({x:116.45,y:226.8},0).wait(1));

	// Layer_3
	this.instance_1 = new lib.CachedBmp_156();
	this.instance_1.setTransform(9.35,292.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24));

	// Layer_1
	this.instance_2 = new lib.Fishy_1();
	this.instance_2.setTransform(452.6,337.4,0.6928,0.7766,0,0,0,122.9,57.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regX:120.6,regY:60.4,x:435.65,y:339.85},0).wait(1).to({x:420.3},0).wait(1).to({x:405},0).wait(1).to({x:389.65},0).wait(1).to({x:374.3},0).wait(1).to({x:359},0).wait(1).to({x:343.65},0).wait(1).to({x:328.3},0).wait(1).to({x:313},0).wait(1).to({x:297.65},0).wait(1).to({x:282.3},0).wait(1).to({x:267},0).wait(1).to({x:251.65},0).wait(1).to({x:236.3},0).wait(1).to({x:221},0).wait(1).to({x:205.65},0).wait(1).to({x:190.3},0).wait(1).to({x:175},0).wait(1).to({x:159.65},0).wait(1).to({x:144.3},0).wait(1).to({x:129},0).wait(1).to({x:113.65},0).wait(1).to({x:98.3},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(284.4,232.9,253.5,164.49999999999997);
// library properties:
lib.properties = {
	id: 'DA095A301C1F504EB26C438A7F6F7FE6',
	width: 550,
	height: 400,
	fps: 24,
	color: "#000066",
	opacity: 1.00,
	manifest: [
		{src:"Fishy_atlas_.png", id:"Fishy_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['DA095A301C1F504EB26C438A7F6F7FE6'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;