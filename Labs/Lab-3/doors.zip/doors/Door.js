(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Door_atlas_", frames: [[0,0,2006,1254]]},
		{name:"Door_atlas_2", frames: [[0,1806,1045,88],[0,1896,1045,88],[0,0,1972,1045],[0,1047,1151,757]]},
		{name:"Door_atlas_3", frames: [[1047,0,239,366],[241,708,49,23],[825,270,13,67],[723,340,55,41],[846,270,16,70],[449,638,20,88],[0,0,1045,88],[0,90,1045,88],[780,340,20,88],[0,180,1045,88],[723,383,20,88],[745,383,20,88],[802,340,20,68],[0,270,239,366],[241,270,239,366],[482,368,239,366],[0,638,239,366],[673,270,150,68],[482,270,189,68],[241,638,206,68],[824,340,20,68],[241,736,705,68]]}
];


// symbols:



(lib.CachedBmp_122copy = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_119 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["Door_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["Door_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["Door_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["Door_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["Door_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_121 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["Door_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Winner = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_102();
	this.instance.setTransform(-494.75,138,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_101();
	this.instance_1.setTransform(-299.55,-167.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_104();
	this.instance_2.setTransform(-494.75,138,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_108();
	this.instance_3.setTransform(-535.15,-271.8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_107();
	this.instance_4.setTransform(-46.5,-48.8,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_106();
	this.instance_5.setTransform(-494.75,138,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_111();
	this.instance_6.setTransform(-130.3,-14.45,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_110();
	this.instance_7.setTransform(-46.5,-48.8,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_109();
	this.instance_8.setTransform(-494.75,138,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_119();
	this.instance_9.setTransform(400.7,-171.95,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_118();
	this.instance_10.setTransform(-292.7,-248.9,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_117();
	this.instance_11.setTransform(26.45,-283.9,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_116();
	this.instance_12.setTransform(210.6,-246.35,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_115();
	this.instance_13.setTransform(-130.3,-14.45,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_114();
	this.instance_14.setTransform(-46.5,-48.8,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_113();
	this.instance_15.setTransform(-494.75,138,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_112();
	this.instance_16.setTransform(-535.15,-376.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},4).to({state:[{t:this.instance_3},{t:this.instance_5},{t:this.instance_4}]},5).to({state:[{t:this.instance_3},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]},5).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9}]},5).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-535.1,-376.3,1011.1,627);


(lib.Door_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_120();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_121();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_122();
	this.instance_2.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_123();
	this.instance_3.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,119.5,183);


(lib.WinningDoor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("fireworks");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.CachedBmp_120();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_121();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.Winner();
	this.instance_2.setTransform(48.45,81.75,0.4949,0.5309,0,0,0,-109.3,22.2);

	this.instance_3 = new lib.CachedBmp_122copy();
	this.instance_3.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_123();
	this.instance_4.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-142.3,-18.7,381.4,201.2);


// stage content:
(lib.Door = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.Win.addEventListener("click", handleMouseClick.bind(this));
		
		function handleMouseClick() 
		{
			alert("Contratulations, you guessed right!");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.CachedBmp_94();
	this.instance.setTransform(67.1,247.4,0.5,0.5);

	this.Win = new lib.WinningDoor();
	this.Win.name = "Win";
	this.Win.setTransform(43.35,103.05);
	new cjs.ButtonHelper(this.Win, 0, 1, 2, false, new lib.WinningDoor(), 3);

	this.instance_1 = new lib.CachedBmp_96();
	this.instance_1.setTransform(398.65,247.4,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_95();
	this.instance_2.setTransform(225.2,247.4,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_93();
	this.instance_3.setTransform(56.9,182.8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_92();
	this.instance_4.setTransform(101.05,57.4,0.5,0.5);

	this.instance_5 = new lib.Door_1();
	this.instance_5.setTransform(384.95,103.05);
	new cjs.ButtonHelper(this.instance_5, 0, 1, 2, false, new lib.Door_1(), 3);

	this.instance_6 = new lib.Door_1();
	this.instance_6.setTransform(217.25,103.05);
	new cjs.ButtonHelper(this.instance_6, 0, 1, 2, false, new lib.Door_1(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.Win},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(176.1,257.4,327.9,28.200000000000045);
// library properties:
lib.properties = {
	id: '4CA4CF1F201B7E4CB379F96C64248317',
	width: 550,
	height: 400,
	fps: 24,
	color: "#336699",
	opacity: 1.00,
	manifest: [
		{src:"images/Door_atlas_.png?1643815514512", id:"Door_atlas_"},
		{src:"images/Door_atlas_2.png?1643815514512", id:"Door_atlas_2"},
		{src:"images/Door_atlas_3.png?1643815514512", id:"Door_atlas_3"},
		{src:"sounds/fireworks.mp3?1643815514545", id:"fireworks"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4CA4CF1F201B7E4CB379F96C64248317'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;