(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Doors_atlas_", frames: [[0,0,2006,1254]]},
		{name:"Doors_atlas_2", frames: [[0,0,1972,1045],[0,1047,1151,757]]},
		{name:"Doors_atlas_3", frames: [[1942,160,49,23],[2026,90,13,67],[1942,0,55,41],[2008,90,16,70],[0,1281,1045,88],[0,1371,1045,88],[1999,0,20,88],[0,1461,1045,88],[0,1551,1045,88],[2021,0,20,88],[0,1641,1045,88],[1942,43,20,88],[1964,43,20,88],[1986,90,20,68],[1059,0,618,508],[0,342,618,508],[620,510,618,508],[1240,510,618,508],[1679,0,239,366],[1047,1154,239,366],[1288,1154,239,366],[1529,1154,239,366],[0,0,1057,340],[1679,428,150,68],[829,412,189,68],[829,342,206,68],[1920,0,20,182],[1047,1522,705,68],[1831,428,136,68],[0,1020,1044,259],[620,342,207,128],[1679,368,316,58],[1046,1020,789,132]]}
];


// symbols:



(lib.CachedBmp_39 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["Doors_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["Doors_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Doors_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["Doors_atlas_3"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Winner = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(-494.75,138,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_21();
	this.instance_1.setTransform(-299.55,-167.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_24();
	this.instance_2.setTransform(-494.75,138,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_28();
	this.instance_3.setTransform(-535.15,-271.8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_27();
	this.instance_4.setTransform(-46.5,-48.8,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_26();
	this.instance_5.setTransform(-494.75,138,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_31();
	this.instance_6.setTransform(-130.3,-14.45,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_30();
	this.instance_7.setTransform(-46.5,-48.8,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_29();
	this.instance_8.setTransform(-494.75,138,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_39();
	this.instance_9.setTransform(400.7,-171.95,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_38();
	this.instance_10.setTransform(-292.7,-248.9,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_37();
	this.instance_11.setTransform(26.45,-283.9,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_36();
	this.instance_12.setTransform(210.6,-246.35,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_35();
	this.instance_13.setTransform(-130.3,-14.45,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_34();
	this.instance_14.setTransform(-46.5,-48.8,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_33();
	this.instance_15.setTransform(-494.75,138,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_32();
	this.instance_16.setTransform(-535.15,-376.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},4).to({state:[{t:this.instance_3},{t:this.instance_5},{t:this.instance_4}]},5).to({state:[{t:this.instance_3},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]},5).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9}]},5).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-535.1,-376.3,1011.1,627);


(lib.Next = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_17();
	this.instance.setTransform(-155.5,-119.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_18();
	this.instance_1.setTransform(-155.5,-119.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_19();
	this.instance_2.setTransform(-155.5,-119.5,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_20();
	this.instance_3.setTransform(-155.5,-119.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-155.5,-119.5,309,254);


(lib.Door = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_40();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_41();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_43();
	this.instance_3.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,119.5,183);


(lib.WinningDoor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("fireworks");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.CachedBmp_40();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_41();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.Winner();
	this.instance_2.setTransform(48.45,81.75,0.4949,0.5309,0,0,0,-109.3,22.2);

	this.instance_3 = new lib.CachedBmp_42();
	this.instance_3.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_43();
	this.instance_4.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-142.3,-18.7,381.4,201.2);


// stage content:
(lib.ex4doors = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{welcome:0,instructions:9,play:19,done:29});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		this.instructions.addEventListener("click", showInstructions.bind(this));
		function showInstructions() {
			this.gotoAndStop("instructions");
		}
		
		this.skipInstructions.addEventListener("click", showGame.bind(this));
		function showGame() {
			this.gotoAndStop("play");
		}
	}
	this.frame_9 = function() {
		this.playGame.addEventListener("click", showGame.bind(this));
		function showGame() {
			this.gotoAndStop("play");
		}
	}
	this.frame_19 = function() {
		this.Win.addEventListener("click", showDone.bind(this));
		
		function showDone() 
		{
			alert("Contratulations, you guessed right!");
			this.gotoAndStop("done");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(10).call(this.frame_19).wait(11));

	// Layer_1
	this.instance = new lib.CachedBmp_46();
	this.instance.setTransform(424.5,315.75,0.5,0.5);

	this.skipInstructions = new lib.Next();
	this.skipInstructions.name = "skipInstructions";
	this.skipInstructions.setTransform(474.3,345.1,0.438,0.353);
	new cjs.ButtonHelper(this.skipInstructions, 0, 1, 2, false, new lib.Next(), 3);

	this.instance_1 = new lib.CachedBmp_2();
	this.instance_1.setTransform(203.35,238,0.5,0.5);

	this.instructions = new lib.Next();
	this.instructions.name = "instructions";
	this.instructions.setTransform(282.2,252.45,0.5925,0.3945,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.instructions, 0, 1, 2, false, new lib.Next(), 3);

	this.instance_2 = new lib.CachedBmp_1();
	this.instance_2.setTransform(81.15,110.55,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_44();
	this.instance_3.setTransform(243.45,277,0.5,0.5);

	this.playGame = new lib.Next();
	this.playGame.name = "playGame";
	this.playGame.setTransform(278.25,290.7,0.6064,0.4351,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.playGame, 0, 1, 2, false, new lib.Next(), 3);

	this.instance_4 = new lib.CachedBmp_3();
	this.instance_4.setTransform(9.3,75.55,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_12();
	this.instance_5.setTransform(67.1,247.4,0.5,0.5);

	this.Win = new lib.WinningDoor();
	this.Win.name = "Win";
	this.Win.setTransform(43.35,103.05);
	new cjs.ButtonHelper(this.Win, 0, 1, 2, false, new lib.WinningDoor(), 3);

	this.instance_6 = new lib.CachedBmp_11();
	this.instance_6.setTransform(398.65,247.4,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_10();
	this.instance_7.setTransform(225.2,247.4,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_9();
	this.instance_8.setTransform(56.9,182.8,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_8();
	this.instance_9.setTransform(101.05,57.4,0.5,0.5);

	this.instance_10 = new lib.Door();
	this.instance_10.setTransform(384.95,103.05);
	new cjs.ButtonHelper(this.instance_10, 0, 1, 2, false, new lib.Door(), 3);

	this.instance_11 = new lib.Door();
	this.instance_11.setTransform(217.25,103.05);
	new cjs.ButtonHelper(this.instance_11, 0, 1, 2, false, new lib.Door(), 3);

	this.instance_12 = new lib.CachedBmp_45();
	this.instance_12.setTransform(8.75,125.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instructions},{t:this.instance_1},{t:this.skipInstructions},{t:this.instance}]}).to({state:[{t:this.instance_4},{t:this.playGame},{t:this.instance_3}]},9).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.Win},{t:this.instance_5}]},10).to({state:[{t:this.instance_12}]},10).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(176.1,257.4,365.5,135.20000000000005);
// library properties:
lib.properties = {
	id: '4CA4CF1F201B7E4CB379F96C64248317',
	width: 550,
	height: 400,
	fps: 24,
	color: "#336699",
	opacity: 1.00,
	manifest: [
		{src:"Doors_atlas_.png", id:"Doors_atlas_"},
		{src:"Doors_atlas_2.png", id:"Doors_atlas_2"},
		{src:"Doors_atlas_3.png", id:"Doors_atlas_3"},
		{src:"fireworks.mp3", id:"fireworks"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4CA4CF1F201B7E4CB379F96C64248317'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;