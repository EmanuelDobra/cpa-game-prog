(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"demoB5_atlas_", frames: [[0,1449,1172,306],[1273,0,695,489],[0,626,1172,425],[0,0,1271,624],[1174,626,785,438],[0,1053,1021,394]]},
		{name:"demoB5_atlas_2", frames: [[1098,0,768,366],[0,871,768,366],[0,1239,768,366],[884,1740,654,250],[1174,368,694,366],[0,0,1096,306],[1174,736,686,359],[0,308,1096,306],[0,616,1172,253],[770,1326,1096,205],[770,1097,1025,227],[884,1533,1096,205],[0,1607,882,314]]},
		{name:"demoB5_atlas_3", frames: [[1098,252,339,360],[1696,744,188,508],[0,1254,307,300],[309,1125,308,299],[309,1426,309,298],[309,1726,309,298],[931,1190,310,297],[1243,1190,310,297],[1243,1553,311,296],[1556,1553,311,296],[0,1556,307,300],[619,1125,308,299],[620,1426,309,298],[620,1726,309,298],[1555,1254,310,297],[931,1553,310,297],[0,0,654,250],[656,0,654,250],[1312,0,654,250],[1109,936,383,252],[1439,252,381,296],[0,252,1096,131],[0,651,1096,124],[1109,744,585,190],[0,385,1096,131],[1098,614,945,128],[0,518,1096,131],[0,777,1107,114],[0,893,1107,114],[0,1009,1107,114]]},
		{name:"demoB5_atlas_4", frames: [[0,596,305,301],[1256,0,305,301],[0,1202,306,300],[0,1504,306,300],[313,594,307,299],[622,594,307,299],[308,1196,308,298],[618,1196,310,296],[313,0,312,295],[313,297,312,295],[941,592,312,294],[941,0,313,294],[1569,605,313,293],[1569,900,313,293],[930,1478,314,292],[1246,901,314,292],[1246,1489,315,291],[0,899,305,301],[1563,0,305,301],[1256,303,306,300],[1564,303,306,300],[307,895,307,299],[616,895,307,299],[308,1496,308,298],[618,1494,310,296],[0,0,311,296],[0,298,311,296],[627,0,312,295],[627,297,312,295],[1255,605,312,294],[941,296,313,294],[931,888,313,293],[930,1183,313,293],[1246,1195,314,292],[1562,1195,314,292],[1563,1489,315,291]]},
		{name:"demoB5_atlas_5", frames: [[1208,1500,297,303],[1507,1522,297,303],[908,1500,298,303],[909,1195,298,303],[607,1500,299,303],[910,887,299,303],[608,890,300,303],[1573,607,301,303],[304,1195,301,302],[0,912,302,302],[0,1216,302,302],[0,0,303,302],[0,304,303,302],[610,0,304,301],[916,0,304,301],[305,304,314,291],[621,303,315,290],[621,595,315,290],[1255,303,316,289],[1209,1192,298,303],[1509,1217,298,303],[1211,887,299,303],[1512,912,299,303],[607,1195,300,303],[305,890,301,303],[304,1499,301,302],[0,1520,302,302],[1573,303,302,302],[305,0,303,302],[0,608,303,302],[1222,0,304,301],[1528,0,304,301],[305,597,314,291],[938,303,315,290],[938,595,315,290],[1255,594,316,289]]},
		{name:"demoB5_atlas_6", frames: [[1187,0,293,304],[595,0,294,303],[298,610,294,304],[0,1220,295,304],[0,1526,295,304],[0,610,296,303],[1017,848,79,280],[1847,1502,83,281],[1372,1606,87,281],[1873,943,91,281],[1859,388,95,280],[508,916,99,279],[1680,942,94,280],[1192,1606,88,280],[1966,943,82,280],[1475,468,77,280],[1176,1026,74,279],[1313,744,77,280],[1017,1130,79,280],[765,1102,82,280],[1675,1499,84,279],[1138,745,77,279],[1151,468,79,275],[1329,1026,74,276],[1405,1032,74,275],[899,1406,80,274],[1252,1026,75,274],[1975,662,73,274],[1481,1032,74,274],[1098,1026,76,274],[1313,468,79,274],[849,1130,82,274],[609,866,84,274],[1960,1226,88,273],[1956,388,92,272],[1878,670,95,271],[1758,388,99,270],[298,916,103,269],[1580,776,98,271],[1676,1224,93,273],[1550,1606,89,274],[725,548,84,275],[1580,306,176,196],[1482,0,293,304],[891,0,294,303],[299,0,294,304],[297,1220,295,304],[297,1526,295,304],[0,915,296,303],[0,0,297,303],[0,305,297,303],[1057,548,79,280],[594,1197,83,281],[1461,1606,87,281],[1776,1216,91,281],[1681,660,95,280],[594,585,99,279],[1580,1049,94,280],[1282,1606,88,280],[849,848,82,280],[1392,744,77,280],[1176,1307,74,279],[1471,750,77,280],[818,1406,79,280],[933,848,82,280],[1761,1499,84,279],[1217,745,77,279],[1232,468,79,275],[1329,1304,74,276],[1405,1309,74,275],[981,1412,80,274],[1252,1302,75,274],[1481,1308,74,274],[1098,1302,76,274],[1394,468,79,274],[933,1130,82,274],[679,1142,84,274],[1960,1501,88,273],[1098,1606,92,272],[1776,943,95,271],[1580,504,99,270],[403,916,103,269],[1778,670,98,271],[1580,1331,93,273],[1869,1226,89,274],[695,825,84,275],[1777,0,219,386],[818,648,236,98],[0,1832,1096,79],[594,1480,222,105],[818,548,237,98],[818,748,236,98],[1580,1963,254,79],[594,1688,269,79],[299,504,424,79],[725,305,424,79],[299,306,424,79],[1151,306,424,79],[0,1913,788,105],[1641,1785,254,79],[1580,1882,269,79],[725,386,424,79],[299,387,424,79],[1151,387,424,79],[725,467,424,79],[790,1913,788,105]]},
		{name:"demoB5_atlas_7", frames: [[75,0,71,279],[0,276,71,279],[433,278,66,278],[219,281,70,277],[291,552,69,277],[501,0,64,278],[633,0,63,278],[633,280,63,278],[501,280,64,278],[567,280,64,277],[362,552,69,276],[294,0,71,274],[72,557,70,274],[294,276,71,274],[148,0,71,279],[221,0,71,279],[433,558,66,278],[0,557,70,277],[216,560,69,277],[501,560,64,278],[633,560,63,278],[698,0,63,278],[567,0,64,278],[567,559,64,277],[367,0,69,276],[73,281,71,274],[144,557,70,274],[146,281,71,274],[0,0,73,274],[287,838,168,105],[457,840,163,75],[0,836,184,98],[367,278,62,218],[698,280,62,218],[186,839,81,56],[0,936,210,59],[622,840,124,79],[457,917,124,79]]}
];


// symbols:



(lib.CachedBmp_267 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_265 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_264 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_263 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_262 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_261 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_260 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_259 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_258 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_257 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_256 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_255 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_254 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_253 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_252 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_251 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_250 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_249 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_248 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_247 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_246 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_245 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_244 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_243 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_242 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_241 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_240 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_239 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_238 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_237 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_236 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_235 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_234 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_233 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_232 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_231 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_230 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_229 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_228 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_227 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_226 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_225 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_224 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_223 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_222 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_221 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_220 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_219 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_218 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_217 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_216 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_215 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_214 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_213 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_212 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_211 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_210 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_209 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_208 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_207 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_206 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_205 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_204 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_203 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_202 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_201 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_200 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_199 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_198 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_197 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_196 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_195 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_194 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_193 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_192 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_191 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_190 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_189 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_188 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_187 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_186 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_185 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_184 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_183 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_182 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_181 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_180 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_179 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_178 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_177 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_176 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_175 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_174 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_173 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_172 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_171 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_170 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_169 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_168 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_167 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_166 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_165 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_164 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_163 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_162 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_161 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_467 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_466 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_465 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_464 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_463 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_462 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_461 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_460 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_459 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_458 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_457 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_456 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_455 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_454 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_453 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_452 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_451 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_450 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_449 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_448 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_447 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_446 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_445 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_444 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_443 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_442 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_441 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_440 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_439 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_438 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_437 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_436 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_435 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_434 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_433 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_432 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_431 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_430 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_429 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_428 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_427 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_426 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_425 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_424 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_423 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_422 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_421 = function() {
	this.initialize(ss["demoB5_atlas_4"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_420 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_419 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_418 = function() {
	this.initialize(ss["demoB5_atlas_5"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_417 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_416 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_415 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_414 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_413 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_412 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_411 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_410 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_409 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_408 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_407 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_406 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_405 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_404 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_403 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_402 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_401 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_400 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_399 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_398 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_397 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_396 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_395 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_394 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_393 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_392 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_391 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_390 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_389 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_388 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_387 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_386 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_385 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_384 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_383 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_382 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_381 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_380 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_379 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_378 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_377 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_376 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_375 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_374 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_373 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_372 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_371 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_370 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_369 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_368 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["demoB5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["demoB5_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["demoB5_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["demoB5_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["demoB5_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["demoB5_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["demoB5_atlas_6"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["demoB5_atlas_7"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["demoB5_atlas_3"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["demoB5_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.VaultButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("fireworks");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.CachedBmp_264();
	this.instance.setTransform(-201.8,-95,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_265();
	this.instance_1.setTransform(-201.8,-95,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_267();
	this.instance_2.setTransform(-201.8,-95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-201.8,-95,384,183);


(lib.an_TextInput = function(options) {
	this.initialize();
	this._element = new $.an.TextInput(options);
	this._el = this._element.create();
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,22);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;
p.draw = _componentDraw;



(lib.Stash = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_263();
	this.instance.setTransform(-85.5,-136.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Stash, new cjs.Rectangle(-85.5,-136.6,169.5,180), null);


(lib.PlayerStickman = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_262();
	this.instance.setTransform(-47.95,-127.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PlayerStickman, new cjs.Rectangle(-47.9,-127.2,94,254), null);


(lib.Heart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_161();
	this.instance.setTransform(-33.4,-33.55,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Heart, new cjs.Rectangle(-33.4,-33.5,63.5,70.6), null);


(lib.Flowey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Armature_11
	this.instance = new lib.CachedBmp_368();
	this.instance.setTransform(-28.9,-44.45,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_369();
	this.instance_1.setTransform(-28.85,-43.85,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_370();
	this.instance_2.setTransform(-28.75,-43.15,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_371();
	this.instance_3.setTransform(-28.7,-42.35,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_372();
	this.instance_4.setTransform(-28.65,-41.45,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_373();
	this.instance_5.setTransform(-28.65,-42.05,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_374();
	this.instance_6.setTransform(-28.7,-42.55,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_375();
	this.instance_7.setTransform(-28.75,-43.05,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_376();
	this.instance_8.setTransform(-28.8,-43.4,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_377();
	this.instance_9.setTransform(-28.8,-43.75,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_378();
	this.instance_10.setTransform(-28.8,-44,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_379();
	this.instance_11.setTransform(-28.8,-44.1,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_380();
	this.instance_12.setTransform(-28.8,-44.1,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_381();
	this.instance_13.setTransform(-28.8,-44,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_382();
	this.instance_14.setTransform(-28.8,-43.8,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_383();
	this.instance_15.setTransform(-28.85,-43.95,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_384();
	this.instance_16.setTransform(-28.9,-44,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_385();
	this.instance_17.setTransform(-30.4,-43.95,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_386();
	this.instance_18.setTransform(-33.45,-43.85,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_387();
	this.instance_19.setTransform(-36.45,-43.7,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_388();
	this.instance_20.setTransform(-33.9,-44.3,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_389();
	this.instance_21.setTransform(-31.4,-44.9,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_390();
	this.instance_22.setTransform(-29.1,-45.35,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_391();
	this.instance_23.setTransform(-29.15,-45.7,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_392();
	this.instance_24.setTransform(-29.15,-46,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_393();
	this.instance_25.setTransform(-29.15,-45.8,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_394();
	this.instance_26.setTransform(-29.15,-45.55,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_395();
	this.instance_27.setTransform(-31.4,-45.25,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_396();
	this.instance_28.setTransform(-33.95,-44.75,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_397();
	this.instance_29.setTransform(-36.5,-44.25,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_398();
	this.instance_30.setTransform(-31.3,-45.2,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_399();
	this.instance_31.setTransform(-29.05,-45.85,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_400();
	this.instance_32.setTransform(-29,-46.3,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_401();
	this.instance_33.setTransform(-28.95,-46.5,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_402();
	this.instance_34.setTransform(-28.9,-46.4,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_403();
	this.instance_35.setTransform(-28.9,-46.6,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_404();
	this.instance_36.setTransform(-28.9,-46.65,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_405();
	this.instance_37.setTransform(-28.9,-46.6,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_406();
	this.instance_38.setTransform(-28.9,-46.45,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_407();
	this.instance_39.setTransform(-28.9,-46.25,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_408();
	this.instance_40.setTransform(-28.9,-46.75,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_409();
	this.instance_41.setTransform(-28.9,-47,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_410();
	this.instance_42.setTransform(-28.9,-47.05,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_411();
	this.instance_43.setTransform(-28.9,-46.8,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_412();
	this.instance_44.setTransform(-28.9,-46.3,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_413();
	this.instance_45.setTransform(-28.9,-46.95,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_414();
	this.instance_46.setTransform(-28.9,-47.35,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_415();
	this.instance_47.setTransform(-28.9,-47.45,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_416();
	this.instance_48.setTransform(-28.85,-47.3,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_417();
	this.instance_49.setTransform(-28.85,-46.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).wait(1));

	// Armature_13
	this.instance_50 = new lib.CachedBmp_418();
	this.instance_50.setTransform(-76.9,-171.2,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_419();
	this.instance_51.setTransform(-76.7,-171.1,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_420();
	this.instance_52.setTransform(-76.5,-171,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_421();
	this.instance_53.setTransform(-76.3,-170.9,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_422();
	this.instance_54.setTransform(-76.1,-170.8,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_423();
	this.instance_55.setTransform(-75.9,-170.7,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_424();
	this.instance_56.setTransform(-75.7,-170.65,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_425();
	this.instance_57.setTransform(-75.5,-170.55,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_426();
	this.instance_58.setTransform(-75.3,-170.45,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_427();
	this.instance_59.setTransform(-75.1,-170.35,0.5,0.5);

	this.instance_60 = new lib.CachedBmp_428();
	this.instance_60.setTransform(-74.9,-170.3,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_429();
	this.instance_61.setTransform(-74.7,-170.15,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_430();
	this.instance_62.setTransform(-74.5,-170.05,0.5,0.5);

	this.instance_63 = new lib.CachedBmp_431();
	this.instance_63.setTransform(-74.25,-169.95,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_432();
	this.instance_64.setTransform(-74.05,-169.85,0.5,0.5);

	this.instance_65 = new lib.CachedBmp_433();
	this.instance_65.setTransform(-73.85,-169.75,0.5,0.5);

	this.instance_66 = new lib.CachedBmp_434();
	this.instance_66.setTransform(-73.65,-169.65,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_435();
	this.instance_67.setTransform(-73.45,-169.55,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_436();
	this.instance_68.setTransform(-73.25,-169.4,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_437();
	this.instance_69.setTransform(-73,-169.3,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_438();
	this.instance_70.setTransform(-72.8,-169.15,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_439();
	this.instance_71.setTransform(-72.6,-169.05,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_440();
	this.instance_72.setTransform(-72.4,-168.95,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_441();
	this.instance_73.setTransform(-72.2,-168.8,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_442();
	this.instance_74.setTransform(-72,-168.65,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_443();
	this.instance_75.setTransform(-71.8,-168.55,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_444();
	this.instance_76.setTransform(-71.6,-168.4,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_445();
	this.instance_77.setTransform(-71.35,-168.3,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_446();
	this.instance_78.setTransform(-71.15,-168.15,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_447();
	this.instance_79.setTransform(-70.95,-168.05,0.5,0.5);

	this.instance_80 = new lib.CachedBmp_448();
	this.instance_80.setTransform(-70.75,-167.9,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_449();
	this.instance_81.setTransform(-70.55,-167.75,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_450();
	this.instance_82.setTransform(-70.3,-167.6,0.5,0.5);

	this.instance_83 = new lib.CachedBmp_451();
	this.instance_83.setTransform(-70.1,-167.5,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_452();
	this.instance_84.setTransform(-69.9,-167.35,0.5,0.5);

	this.instance_85 = new lib.CachedBmp_453();
	this.instance_85.setTransform(-69.7,-167.2,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_454();
	this.instance_86.setTransform(-69.5,-167.05,0.5,0.5);

	this.instance_87 = new lib.CachedBmp_455();
	this.instance_87.setTransform(-69.3,-166.9,0.5,0.5);

	this.instance_88 = new lib.CachedBmp_456();
	this.instance_88.setTransform(-69.1,-166.8,0.5,0.5);

	this.instance_89 = new lib.CachedBmp_457();
	this.instance_89.setTransform(-68.85,-166.6,0.5,0.5);

	this.instance_90 = new lib.CachedBmp_458();
	this.instance_90.setTransform(-68.65,-166.45,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_459();
	this.instance_91.setTransform(-68.45,-166.3,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_460();
	this.instance_92.setTransform(-68.25,-166.15,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_461();
	this.instance_93.setTransform(-68,-166,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_462();
	this.instance_94.setTransform(-67.8,-165.85,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_463();
	this.instance_95.setTransform(-67.6,-165.7,0.5,0.5);

	this.instance_96 = new lib.CachedBmp_464();
	this.instance_96.setTransform(-67.4,-165.5,0.5,0.5);

	this.instance_97 = new lib.CachedBmp_465();
	this.instance_97.setTransform(-67.2,-165.35,0.5,0.5);

	this.instance_98 = new lib.CachedBmp_466();
	this.instance_98.setTransform(-66.95,-165.15,0.5,0.5);

	this.instance_99 = new lib.CachedBmp_467();
	this.instance_99.setTransform(-66.75,-165,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_50}]}).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_57}]},1).to({state:[{t:this.instance_58}]},1).to({state:[{t:this.instance_59}]},1).to({state:[{t:this.instance_60}]},1).to({state:[{t:this.instance_61}]},1).to({state:[{t:this.instance_62}]},1).to({state:[{t:this.instance_63}]},1).to({state:[{t:this.instance_64}]},1).to({state:[{t:this.instance_65}]},1).to({state:[{t:this.instance_66}]},1).to({state:[{t:this.instance_67}]},1).to({state:[{t:this.instance_68}]},1).to({state:[{t:this.instance_69}]},1).to({state:[{t:this.instance_70}]},1).to({state:[{t:this.instance_71}]},1).to({state:[{t:this.instance_72}]},1).to({state:[{t:this.instance_73}]},1).to({state:[{t:this.instance_74}]},1).to({state:[{t:this.instance_75}]},1).to({state:[{t:this.instance_76}]},1).to({state:[{t:this.instance_77}]},1).to({state:[{t:this.instance_78}]},1).to({state:[{t:this.instance_79}]},1).to({state:[{t:this.instance_80}]},1).to({state:[{t:this.instance_81}]},1).to({state:[{t:this.instance_82}]},1).to({state:[{t:this.instance_83}]},1).to({state:[{t:this.instance_84}]},1).to({state:[{t:this.instance_85}]},1).to({state:[{t:this.instance_86}]},1).to({state:[{t:this.instance_87}]},1).to({state:[{t:this.instance_88}]},1).to({state:[{t:this.instance_89}]},1).to({state:[{t:this.instance_90}]},1).to({state:[{t:this.instance_91}]},1).to({state:[{t:this.instance_92}]},1).to({state:[{t:this.instance_93}]},1).to({state:[{t:this.instance_94}]},1).to({state:[{t:this.instance_95}]},1).to({state:[{t:this.instance_96}]},1).to({state:[{t:this.instance_97}]},1).to({state:[{t:this.instance_98}]},1).to({state:[{t:this.instance_99}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.9,-171.2,158.5,264.7);


(lib.DefaultButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_57();
	this.instance.setTransform(-166.3,-69.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_58();
	this.instance_1.setTransform(-166.3,-69.7,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_59();
	this.instance_2.setTransform(-166.3,-69.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_60();
	this.instance_3.setTransform(-166.3,-69.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-166.3,-69.7,327,125);


(lib.Clouds = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_56();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Clouds, new cjs.Rectangle(0,0,347,183), null);


(lib.Bandit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_55();
	this.instance.setTransform(-56.55,-117.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Bandit, new cjs.Rectangle(-56.5,-117.3,109.5,193), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PlayerStickman();
	this.instance.setTransform(50.55,108.65,0.552,0.4227,0,0,0,-0.9,-0.2);

	this.instance_1 = new lib.Heart();
	this.instance_1.setTransform(50.45,55.25,1.3867,0.7209,0,0,0,-1.7,1.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(6.5,29.8,88,132.6), null);


(lib.Other3Bandits = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bandit();
	this.instance.setTransform(83.5,131,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_1 = new lib.Bandit();
	this.instance_1.setTransform(39.15,88.85,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_2 = new lib.Bandit();
	this.instance_2.setTransform(124.35,64.95,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Other3Bandits, new cjs.Rectangle(-1.1,-1,165.7,198), null);


(lib.CloudsMoving = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Clouds();
	this.instance.setTransform(173.6,91.4,1,1,0,0,0,173.6,91.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:173.5,regY:91.5,x:198.5,y:70.35},0).wait(1).to({x:222.35,y:52.4},0).wait(1).to({x:244.95,y:37.75},0).wait(1).to({x:266.35,y:26.35},0).wait(1).to({x:286.55,y:18.2},0).wait(1).to({x:305.55,y:13.3},0).wait(1).to({x:323.35,y:11.7},0).wait(1).to({x:339.95,y:13.3},0).wait(1).to({x:355.4,y:18.2},0).wait(1).to({x:369.6,y:26.35},0).wait(1).to({x:382.6,y:37.75},0).wait(1).to({x:394.4,y:52.4},0).wait(1).to({x:405.05,y:70.3},0).wait(1).to({x:414.5,y:91.5},0).wait(1).to({x:412.45,y:56.4},0).wait(1).to({x:405.05,y:25},0).wait(1).to({x:392.3,y:-2.75},0).wait(1).to({x:374.15,y:-26.8},0).wait(1).to({x:350.65,y:-47.2},0).wait(1).to({x:321.75,y:-63.95},0).wait(1).to({x:287.5,y:-77},0).wait(1).to({x:247.85,y:-86.35},0).wait(1).to({x:202.8,y:-92.1},0).wait(1).to({x:152.4,y:-94.1},0).wait(1).to({x:96.5,y:-92.5},0).wait(1).to({x:51.55,y:-93.2},0).wait(1).to({x:12.35,y:-88.3},0).wait(1).to({x:-21.1,y:-77.75},0).wait(1).to({x:-48.8,y:-61.6},0).wait(1).to({x:-70.8,y:-39.75},0).wait(1).to({x:-87.1,y:-12.35},0).wait(1).to({x:-97.6,y:20.75},0).wait(1).to({x:-102.45,y:59.5},0).wait(1).to({x:-56,y:47.3},0).wait(1).to({x:-12.8,y:42.9},0).wait(1).to({x:27.05,y:46.25},0).wait(1).to({x:63.65,y:57.35},0).wait(1).to({x:97,y:76.2},0).wait(1).to({x:127.1,y:102.8},0).wait(1).to({x:153.95,y:137.25},0).wait(1).to({x:177.5,y:179.5},0).wait(1).to({x:204.5,y:151.1},0).wait(1).to({x:221.25,y:124.5},0).wait(1).to({x:227.75,y:99.65},0).wait(1).to({x:224.05,y:76.55},0).wait(1).to({x:210.1,y:55.15},0).wait(1).to({x:185.9,y:35.45},0).wait(1).to({x:151.5,y:17.45},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-275.9,-185.6,863.9,456.6);


(lib._3Bandits = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bandit();
	this.instance.setTransform(90.95,107.4,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_1 = new lib.Bandit();
	this.instance_1.setTransform(39.15,88.85,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_2 = new lib.Bandit();
	this.instance_2.setTransform(124.35,64.95,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._3Bandits, new cjs.Rectangle(-1.1,-1,165.7,174.4), null);


// stage content:
(lib.demoB5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{customize:104,instructions:108,adventure:113,bandits:118,question:123,banditsDef:128,banditsAtk:153,vault:198,defeat:203});

	// timeline functions:
	this.frame_104 = function() {
		this.stop();
		game = this;
		
		// Update Hearts 
		playerHearts = Math.floor(Math.random()*3)+1;
		game.heartsOut.text = playerHearts;
		
		// Update name UI each 1 second
		const interval = setInterval(function() {
		   updateName();
		 }, 1000);
		 
		// Function to update name variable and text
		function updateName() {
			playerName = document.getElementById("nameInput").value;
			game.playerOut.text = playerName;
		}
		
		// Set default stats
		playerInt = 5;
		playerStr = 5;
		playerDex = 5;
		game.intOut.text = playerInt;
		game.strOut.text = playerStr;
		game.dexOut.text = playerDex;
		
		
		// Update player stats
		game.randomizeStats_btn.addEventListener("click", randomize);
		function randomize() {
			// Randomize scenario stats 1-9
			playerInt = Math.floor(Math.random()*9)+1;
			playerStr = Math.floor(Math.random()*9)+1;
			playerDex = Math.floor(Math.random()*9)+1;
			game.intOut.text = playerInt;
			game.strOut.text = playerStr;
			game.dexOut.text = playerDex;
			// Randomize hp 1-3
			playerHearts = Math.floor(Math.random()*3)+1;
			game.heartsOut.text = playerHearts;
		}
		
		game.startGame_btn.addEventListener("click", start);
		function start() {
			updateName();
			if (playerName != "") {
				// Remove event listeners and go to next frame
				game.randomizeStats_btn.removeEventListener("click", randomize);
				game.startGame_btn.removeEventListener("click", start);
				// Clear interval to prevent memory leak
				clearInterval(interval);
				// Go to instructions frame
				game.gotoAndStop("instructions");
			} else {
				alert("You must enter in your name!");
			}
		}
	}
	this.frame_108 = function() {
		game.continue_btn.addEventListener("click", startAdventure);
		function startAdventure() {
			game.continue_btn.removeEventListener("click", startAdventure);
			game.gotoAndStop("adventure");
		}
	}
	this.frame_113 = function() {
		game.begin_btn.addEventListener("click", begin);
		function begin() {
			game.begin_btn.removeEventListener("click", begin);
			game.gotoAndStop("bandits");
		}
	}
	this.frame_118 = function() {
		// Update user hearts UI
		game.HPOut.text = playerHearts;
		
		var rollResult;
		
		// Setup roll dice button
		this.roll_btn.addEventListener("click", roll);
		function roll() {
			rollResult = Math.floor(Math.random()*20)+1;
			outcomeResult = rollResult + playerStr;
			alert("You rolled a " + rollResult 
				+ "!\nYour strength is: " + playerStr);
			if (outcomeResult >= 15) {
				alert("You successfully ambush the bandits and get the first attack in!");
			} else {
				alert("You failed to ambush the bandits, its time to defend against their attack!");
			}
			game.roll_btn.removeEventListener("click", roll);
			game.gotoAndStop("question");
		}
	}
	this.frame_123 = function() {
		// Set up random math addition
		var numOne = Math.floor(Math.random()*99)+1;
		var numTwo = Math.floor(Math.random()*99)+1;
		game.numOneOut.text = numOne;
		game.numTwoOut.text = numTwo;
		
		// Setup result
		var userAnswer;
		var correct = numOne + numTwo;
		
		// Setup button
		game.proceed_btn.addEventListener("click", proceed);
		function proceed() {
			// Get user guess
			userAnswer = document.getElementById("answerInput").value;
			// If incorrect, remove a heart
			if (userAnswer != correct) {
				alert("Wrong! The answer was " + correct + "\nYou lost a heart!");
				playerHearts -= 1;
			} else {
				alert("Correct, you got it right!");
			}
			// Remove eventListener
			game.proceed_btn.removeEventListener("click", proceed);
			// Defeat or continue scenarios
			if (playerHearts < 1) {
				game.gotoAndStop("defeat");
			} else {
				// If the user has already defended once
				if (hasDefended) {
					game.gotoAndPlay("banditsAtk");
				}
				// Otherwise if has fought, go directly to atk
				else {
					// If user got good roll, skip to atk
					if (outcomeResult >= 15) {
						game.gotoAndPlay("banditsAtk");
					} else {
						// Otherwise go to def
						game.gotoAndPlay("banditsDef");
					}
				}
		
			}
		}
	}
	this.frame_128 = function() {
		game.hpOut.text = playerHearts;
		hasDefended = true;
		
		// Setup attack button
		game.attack_btn.addEventListener("click", attack);
		function attack() {
			game.gotoAndStop("question");
		}
	}
	this.frame_152 = function() {
		game.stop();
	}
	this.frame_153 = function() {
		game.final_btn.addEventListener("click", nextFrame);
		function nextFrame() {
			game.gotoAndStop("vault");
		}
	}
	this.frame_197 = function() {
		game.stop();
	}
	this.frame_198 = function() {
		game.new_btn.addEventListener("click", restart);
		function restart() {
			// Reset defense 
			hasDefended = false;
			game.gotoAndStop("customize");
		}
	}
	this.frame_203 = function() {
		game.retry_btn.addEventListener("click", retry);
		function retry() {
			// Reset defense 
			hasDefended = false;
			game.gotoAndStop("customize");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(104).call(this.frame_104).wait(4).call(this.frame_108).wait(5).call(this.frame_113).wait(5).call(this.frame_118).wait(5).call(this.frame_123).wait(5).call(this.frame_128).wait(24).call(this.frame_152).wait(1).call(this.frame_153).wait(44).call(this.frame_197).wait(1).call(this.frame_198).wait(5).call(this.frame_203).wait(5));

	// mask_circle (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AjuDjQhJhIABhnQgBhlBJhIQBIhJBmABQBmgBBIBJQBIBIABBlQgBBnhIBIQhIBIhmABQhmgBhIhIg");
	var mask_graphics_1 = new cjs.Graphics().p("AixDkQhJhJAAhoQAAhnBJhJQBKhJBnAAQBoAABKBJQBJBJAABnQAABohJBJQhKBJhoAAQhnAAhKhJg");
	var mask_graphics_2 = new cjs.Graphics().p("Ai0DkQhLhJAAhpQAAhpBLhKQBLhKBpAAQBqAABLBKQBLBKAABpQAABphLBJQhLBLhqAAQhpAAhLhLg");
	var mask_graphics_3 = new cjs.Graphics().p("Ai4DlQhLhLAAhqQAAhqBLhLQBNhLBrAAQBsAABMBLQBMBLAABqQAABqhMBLQhMBLhsAAQhrAAhNhLg");
	var mask_graphics_4 = new cjs.Graphics().p("AiYDmQhNhMAAhsQAAhqBNhNQBOhLBtAAQBtAABOBLQBNBNAABqQAABshNBMQhOBMhtAAQhtAAhOhMg");
	var mask_graphics_5 = new cjs.Graphics().p("AhFDmQhOhNAAhsQAAhsBOhNQBOhNBwAAQBwAABPBNQBPBNAABsQAABshPBNQhPBNhwAAQhwAAhOhNg");
	var mask_graphics_6 = new cjs.Graphics().p("AAODmQhPhNAAhuQAAhtBPhOQBQhOByAAQBxAABQBOQBRBOAABtQAABuhRBNQhQBOhxAAQhyAAhQhOg");
	var mask_graphics_7 = new cjs.Graphics().p("ABhDnQhRhOAAhwQAAhuBRhPQBShOBzAAQB0AABRBOQBSBPAABuQAABwhSBOQhRBPh0AAQhzAAhShPg");
	var mask_graphics_8 = new cjs.Graphics().p("AC1DoQhThPAAhxQAAhwBThQQBThPB1AAQB1AABTBPQBTBQAABwQAABxhTBPQhTBQh1AAQh1AAhThQg");
	var mask_graphics_9 = new cjs.Graphics().p("AEIDoQhUhQAAhyQAAhxBUhRQBUhQB3AAQB4AABTBQQBVBRAABxQAAByhVBQQhTBRh4AAQh3AAhUhRg");
	var mask_graphics_10 = new cjs.Graphics().p("AFhDpQhVhRAAh0QAAhyBVhRQBWhSB5AAQB5AABVBSQBWBRAAByQAAB0hWBRQhVBSh5AAQh5AAhWhSg");
	var mask_graphics_11 = new cjs.Graphics().p("AG6DqQhWhSAAh1QAAh0BWhSQBXhSB7AAQB7AABWBSQBXBSAAB0QAAB1hXBSQhWBSh7AAQh7AAhXhSg");
	var mask_graphics_12 = new cjs.Graphics().p("AITDqQhYhTAAh2QAAh1BYhTQBYhTB9AAQB9AABXBTQBZBTAAB1QAAB2hZBTQhXBTh9AAQh9AAhYhTg");
	var mask_graphics_13 = new cjs.Graphics().p("AJsDrQhZhUAAh3QAAh2BZhVQBahTB+AAQB/AABZBTQBZBVAAB2QAAB3hZBUQhZBUh/AAQh+AAhahUg");
	var mask_graphics_14 = new cjs.Graphics().p("ALFDrQhbhUAAh5QAAh3BbhWQBahUCBAAQCBAABaBUQBbBWAAB3QAAB5hbBUQhaBWiBAAQiBAAhahWg");
	var mask_graphics_15 = new cjs.Graphics().p("AMeDsQhchVAAh6QAAh5BchWQBchWCCAAQCDAABbBWQBdBWAAB5QAAB6hdBVQhbBWiDAAQiCAAhchWg");
	var mask_graphics_16 = new cjs.Graphics().p("AN3DtQhdhXAAh7QAAh6BdhXQBdhWCFAAQCEAABdBWQBdBXAAB6QAAB7hdBXQhdBXiEAAQiFAAhdhXg");
	var mask_graphics_17 = new cjs.Graphics().p("APQDtQhfhXAAh8QAAh8BfhYQBehXCGAAQCHAABeBXQBfBYAAB8QAAB8hfBXQheBYiHAAQiGAAhehYg");
	var mask_graphics_18 = new cjs.Graphics().p("AQpDuQhghYAAh+QAAh9BghZQBghYCIAAQCIAABfBYQBgBZAAB9QAAB+hgBYQhfBZiIAAQiIAAhghZg");
	var mask_graphics_19 = new cjs.Graphics().p("ASCDvQhhhZAAh/QAAh+BhhaQBhhZCKAAQCKAABhBZQBhBaAAB+QAAB/hhBZQhhBaiKAAQiKAAhhhag");
	var mask_graphics_20 = new cjs.Graphics().p("ATmDvQhihaAAiAQAAh/BihbQBjhaCLAAQCMAABiBaQBjBbAAB/QAACAhjBaQhiBbiMAAQiLAAhjhbg");
	var mask_graphics_21 = new cjs.Graphics().p("AVKDwQhkhbAAiBQAAiBBkhcQBkhbCNAAQCOAABjBbQBlBcAACBQAACBhlBbQhjBciOAAQiNAAhkhcg");
	var mask_graphics_22 = new cjs.Graphics().p("AWuDxQhlhcAAiDQAAiCBlhcQBlhcCQAAQCPAABlBcQBlBcAACCQAACDhlBcQhlBciPAAQiQAAhlhcg");
	var mask_graphics_23 = new cjs.Graphics().p("AYSDxQhmhdAAiEQAAiDBmhdQBnhdCRAAQCRAABnBdQBmBdAACDQAACEhmBdQhnBeiRAAQiRAAhnheg");
	var mask_graphics_24 = new cjs.Graphics().p("AZ2DyQhnheAAiFQAAiFBnheQBoheCTAAQCUAABnBeQBoBeAACFQAACFhoBeQhnBeiUAAQiTAAhoheg");
	var mask_graphics_25 = new cjs.Graphics().p("AbaDyQhoheAAiHQAAiGBohfQBqhfCVAAQCVAABoBfQBqBfAACGQAACHhqBeQhoBgiVAAQiVAAhqhgg");
	var mask_graphics_26 = new cjs.Graphics().p("Ac/DzQhqhfAAiIQAAiHBqhgQBqhgCXAAQCXAABqBgQBrBgAACHQAACIhrBfQhqBgiXAAQiXAAhqhgg");
	var mask_graphics_27 = new cjs.Graphics().p("AejD0QhrhgAAiKQAAiIBrhhQBshgCYgBQCZABBrBgQBsBhAACIQAACKhsBgQhrBhiZAAQiYAAhshhg");
	var mask_graphics_28 = new cjs.Graphics().p("EAgHAD0QhthhAAiKQAAiKBthiQBthhCbAAQCaAABtBhQBtBiAACKQAACKhtBhQhtBiiaAAQibAAhthig");
	var mask_graphics_29 = new cjs.Graphics().p("EAhrAD1QhuhiAAiMQAAiLBuhjQBvhiCcAAQCdAABuBiQBuBjAACLQAACMhuBiQhuBjidAAQicAAhvhjg");
	var mask_graphics_30 = new cjs.Graphics().p("EAgjAEAQhwhjAAiNQAAiMBwhkQBvhjCfAAQCeAABvBjQBwBkAACMQAACNhwBjQhvBkieAAQifAAhvhkg");
	var mask_graphics_31 = new cjs.Graphics().p("AfaELQhxhkAAiOQAAiOBxhlQBxhkCgAAQCgAABxBkQBxBlAACOQAACOhxBkQhxBligAAQigAAhxhlg");
	var mask_graphics_32 = new cjs.Graphics().p("AeREWQhyhlAAiQQAAiOByhmQBzhlChAAQCiAAByBlQBzBmAACOQAACQhzBlQhyBmiiAAQihAAhzhmg");
	var mask_graphics_33 = new cjs.Graphics().p("AdJEhQh0hmAAiRQAAiPB0hnQBzhmCkAAQCkAABzBmQB0BnAACPQAACRh0BmQhzBnikAAQikAAhzhng");
	var mask_graphics_34 = new cjs.Graphics().p("AcAEsQh1hmAAiTQAAiRB1hnQB1hnCmAAQClAAB1BnQB1BnAACRQAACTh1BmQh1BoilAAQimAAh1hog");
	var mask_graphics_35 = new cjs.Graphics().p("Aa3E3Qh2hnAAiUQAAiTB2hoQB3hoCnAAQCoAAB2BoQB2BoAACTQAACUh2BnQh2BpioAAQinAAh3hpg");
	var mask_graphics_36 = new cjs.Graphics().p("AZuFCQh3hoAAiVQAAiUB3hpQB4hpCpAAQCqAAB3BpQB4BpAACUQAACVh4BoQh3BpiqAAQipAAh4hpg");
	var mask_graphics_37 = new cjs.Graphics().p("AYlFNQh4hpAAiXQAAiVB4hqQB5hpCsAAQCrAAB4BpQB5BqAACVQAACXh5BpQh4BqirAAQisAAh5hqg");
	var mask_graphics_38 = new cjs.Graphics().p("AXdFZQh6hrAAiXQAAiXB6hrQB6hqCtAAQCuAAB5BqQB7BrAACXQAACXh7BrQh5BriuAAQitAAh6hrg");
	var mask_graphics_39 = new cjs.Graphics().p("AWUFjQh7hrAAiYQAAiYB7hsQB8hrCvAAQCvAAB7BrQB7BsAACYQAACYh7BrQh7BsivAAQivAAh8hsg");
	var mask_graphics_40 = new cjs.Graphics().p("AVMFuQh9hsAAiaQAAiZB9htQB9hsCxAAQCwAAB9BsQB9BtAACZQAACah9BsQh9BtiwAAQixAAh9htg");
	var mask_graphics_41 = new cjs.Graphics().p("AUDF6Qh+htAAicQAAiaB+huQB+htCzAAQCzAAB9BtQB/BuAACaQAACch/BtQh9BtizAAQizAAh+htg");
	var mask_graphics_42 = new cjs.Graphics().p("AS6GEQh/huAAicQAAicB/hvQCAhuC0AAQC1AAB/BuQB/BvAACcQAACch/BuQh/Bvi1AAQi0AAiAhvg");
	var mask_graphics_43 = new cjs.Graphics().p("ARxGPQiAhuAAieQAAidCAhwQCBhvC3AAQC2AACABvQCBBwAACdQAACeiBBuQiABwi2AAQi3AAiBhwg");
	var mask_graphics_44 = new cjs.Graphics().p("AQpGbQiChwAAifQAAieCChxQCChwC4AAQC5AACBBwQCCBxAACeQAACfiCBwQiBBwi5AAQi4AAiChwg");
	var mask_graphics_45 = new cjs.Graphics().p("APgGmQiDhxAAihQAAifCDhxQCEhxC6AAQC6AACDBxQCDBxAACfQAAChiDBxQiDBxi6AAQi6AAiEhxg");
	var mask_graphics_46 = new cjs.Graphics().p("AOXGxQiEhyAAiiQAAigCEhzQCFhxC8AAQC8AACEBxQCFBzAACgQAACiiFByQiEByi8AAQi8AAiFhyg");
	var mask_graphics_47 = new cjs.Graphics().p("ANOG8QiFhzAAijQAAijCFhyQCHhzC+AAQC9AACGBzQCGByAACjQAACjiGBzQiGBzi9AAQi+AAiHhzg");
	var mask_graphics_48 = new cjs.Graphics().p("AMGHHQiHh0AAikQAAikCHhzQCIh0C/AAQDAAACHB0QCHBzAACkQAACkiHB0QiHB0jAAAQi/AAiIh0g");
	var mask_graphics_49 = new cjs.Graphics().p("AK9HSQiIh0AAimQAAimCIh0QCJh0DCAAQDBAACIB0QCJB0AACmQAACmiJB0QiIB1jBAAQjCAAiJh1g");
	var mask_graphics_50 = new cjs.Graphics().p("AKhHtQiPh9AAiyQAAiyCPh9QCRh8DMAAQDMAACPB8QCRB9AACyQAACyiRB9QiPB9jMAAQjMAAiRh9g");
	var mask_graphics_51 = new cjs.Graphics().p("AKFIHQiXiFAAi+QAAi+CXiFQCYiGDXAAQDXAACXCGQCYCFAAC+QAAC+iYCFQiXCHjXAAQjXAAiYiHg");
	var mask_graphics_52 = new cjs.Graphics().p("AJpIjQieiOAAjKQAAjLCeiOQCgiODhAAQDhAACfCOQCfCOAADLQAADKifCOQifCPjhAAQjhAAigiPg");
	var mask_graphics_53 = new cjs.Graphics().p("AJNI+QimiXAAjXQAAjVCmiYQCniWDsAAQDsAACmCWQCnCYAADVQAADXinCXQimCXjsAAQjsAAiniXg");
	var mask_graphics_54 = new cjs.Graphics().p("AIxJZQiuigAAjiQAAjiCuigQCuifD3AAQD3AACtCfQCvCgAADiQAADiivCgQitCgj3AAQj3AAiuigg");
	var mask_graphics_55 = new cjs.Graphics().p("AIVJzQi1inAAjvQAAjuC1ipQC2ioEBAAQECAAC0CoQC2CpAADuQAADvi2CnQi0CpkCAAQkBAAi2ipg");
	var mask_graphics_56 = new cjs.Graphics().p("AH5KOQi9iwAAj7QAAj6C9iyQC9iwEMAAQEMAAC8CwQC+CyAAD6QAAD7i+CwQi8CykMAAQkMAAi9iyg");
	var mask_graphics_57 = new cjs.Graphics().p("AHdKpQjEi5AAkHQAAkGDEi7QDFi4EWAAQEXAADEC4QDFC7AAEGQAAEHjFC5QjEC6kXAAQkWAAjFi6g");
	var mask_graphics_58 = new cjs.Graphics().p("AHALEQjLjBAAkUQAAkTDLjCQDNjCEhAAQEhAADMDCQDMDCAAETQAAEUjMDBQjMDDkhAAQkhAAjNjDg");
	var mask_graphics_59 = new cjs.Graphics().p("AGkLfQjSjKAAkgQAAkfDSjLQDUjKEsAAQEsAADTDKQDUDLAAEfQAAEgjUDKQjTDLksAAQksAAjUjLg");
	var mask_graphics_60 = new cjs.Graphics().p("AGIL6QjajTAAkrQAAkrDajVQDcjSE2AAQE3AADaDSQDbDVAAErQAAErjbDTQjaDUk3AAQk2AAjcjUg");
	var mask_graphics_61 = new cjs.Graphics().p("AFsMVQjhjbAAk5QAAk3DhjcQDjjcFBAAQFCAADhDcQDjDcAAE3QAAE5jjDbQjhDdlCAAQlBAAjjjdg");
	var mask_graphics_62 = new cjs.Graphics().p("AFQMwQjpjkAAlEQAAlEDpjlQDrjkFLAAQFMAADpDkQDrDlAAFEQAAFEjrDkQjpDllMAAQlLAAjrjlg");
	var mask_graphics_63 = new cjs.Graphics().p("AE0NLQjwjtAAlQQAAlQDwjuQDyjsFXAAQFWAADxDsQDyDuAAFQQAAFQjyDtQjxDulWAAQlXAAjyjug");
	var mask_graphics_64 = new cjs.Graphics().p("AEYNmQj4j1AAldQAAlcD4j3QD5j1FiAAQFhAAD3D1QD6D3AAFcQAAFdj6D1Qj3D2lhAAQliAAj5j2g");
	var mask_graphics_65 = new cjs.Graphics().p("AD8OBQj/j+AAlpQAAloD/j/QEBj+FsAAQFrAAEAD+QEBD/AAFoQAAFpkBD+QkAD/lrAAQlsAAkBj/g");
	var mask_graphics_66 = new cjs.Graphics().p("ADgObQkGkGAAl1QAAl0EGkIQEIkGF3AAQF2AAEHEGQEJEIAAF0QAAF1kJEGQkHEIl2AAQl3AAkIkIg");
	var mask_graphics_67 = new cjs.Graphics().p("ADEO2QkNkOAAmCQAAmAENkRQEQkPGBAAQGBAAEOEPQEQERAAGAQAAGCkQEOQkOERmBAAQmBAAkQkRg");
	var mask_graphics_68 = new cjs.Graphics().p("ACoPRQkVkXAAmOQAAmMEVkaQEXkXGMAAQGMAAEVEXQEYEaAAGMQAAGOkYEXQkVEZmMAAQmMAAkXkZg");
	var mask_graphics_69 = new cjs.Graphics().p("ACMPsQkdkgAAmZQAAmZEdkiQEfkgGWAAQGWAAEdEgQEgEiAAGZQAAGZkgEgQkdEimWAAQmWAAkfkig");
	var mask_graphics_70 = new cjs.Graphics().p("ABvQHQkjkoAAmmQAAmlEjkrQEnkoGhAAQGhAAElEoQEmErAAGlQAAGmkmEoQklErmhAAQmhAAknkrg");
	var mask_graphics_71 = new cjs.Graphics().p("ABUQiQkskxAAmyQAAmyEskzQEukxGrAAQGsAAEsExQEuEzAAGyQAAGykuExQksEzmsAAQmrAAkukzg");
	var mask_graphics_72 = new cjs.Graphics().p("AA3Q9Qkyk6AAm+QAAm9Eyk8QE2k6G2AAQG2AAE0E6QE2E8AAG9QAAG+k2E6Qk0E8m2AAQm2AAk2k8g");
	var mask_graphics_73 = new cjs.Graphics().p("AAcRYQk7lCAAnLQAAnKE7lEQE9lCHBAAQHAAAE7FCQE+FEAAHKQAAHLk+FCQk7FEnAAAQnBAAk9lEg");
	var mask_graphics_74 = new cjs.Graphics().p("AAARzQlClLAAnXQAAnWFClNQFElLHLAAQHMAAFCFLQFFFNAAHWQAAHXlFFLQlCFNnMAAQnLAAlElNg");
	var mask_graphics_75 = new cjs.Graphics().p("AhHR7QlUlWAAnnQAAnlFUlZQFVlVHkAAQHkAAFUFVQFWFZAAHlQAAHnlWFWQlUFYnkAAQnkAAlVlYg");
	var mask_graphics_76 = new cjs.Graphics().p("AiPSDQlllhAAn2QAAn2FlljQFnlhH8AAQH9AAFlFhQFoFjAAH2QAAH2loFhQllFjn9AAQn8AAlnljg");
	var mask_graphics_77 = new cjs.Graphics().p("AjWSLQl3lsAAoGQAAoFF3lvQF4lrIVAAQIVAAF2FrQF5FvAAIFQAAIGl5FsQl2FuoVAAQoVAAl4lug");
	var mask_graphics_78 = new cjs.Graphics().p("AkeSSQmIl3AAoVQAAoVGIl5QGJl3IuAAQIuAAGIF3QGKF5AAIVQAAIVmKF3QmIF6ouAAQouAAmJl6g");
	var mask_graphics_79 = new cjs.Graphics().p("AlmSaQmZmCAAolQAAokGZmFQGbmCJGAAQJHAAGZGCQGcGFAAIkQAAIlmcGCQmZGFpHAAQpGAAmbmFg");
	var mask_graphics_80 = new cjs.Graphics().p("AmuSiQmqmNAAo1QAAo0GqmQQGumNJeAAQJfAAGqGNQGtGQAAI0QAAI1mtGNQmqGQpfAAQpeAAmumQg");
	var mask_graphics_81 = new cjs.Graphics().p("An2SqQm7mYAApFQAApEG7maQG/mYJ3AAQJ3AAG8GYQG/GaAAJEQAAJFm/GYQm8Gap3AAQp3AAm/mag");
	var mask_graphics_82 = new cjs.Graphics().p("Ao9SyQnNmjAApVQAApTHNmmQHQmjKPAAQKQAAHNGjQHRGmAAJTQAAJVnRGjQnNGlqQAAQqPAAnQmlg");
	var mask_graphics_83 = new cjs.Graphics().p("AqFS5QnemuAApkQAApjHemxQHimuKoAAQKpAAHeGuQHhGxAAJjQAAJknhGuQneGxqpAAQqoAAnimxg");
	var mask_graphics_84 = new cjs.Graphics().p("ArNTBQnvm5AApzQAApzHvm8QHzm5LBAAQLBAAHwG5QHzG8AAJzQAAJznzG5QnwG8rBAAQrBAAnzm8g");
	var mask_graphics_85 = new cjs.Graphics().p("AsUTJQoBnEAAqEQAAqCIBnHQIEnELZAAQLaAAIBHEQIFHHAAKCQAAKEoFHEQoBHHraAAQrZAAoEnHg");
	var mask_graphics_86 = new cjs.Graphics().p("AtcTRQoSnPAAqTQAAqSISnTQIWnOLyAAQLyAAITHOQIVHTAAKSQAAKToVHPQoTHSryAAQryAAoWnSg");
	var mask_graphics_87 = new cjs.Graphics().p("AukTYQojnZAAqjQAAqiIjndQIonaMKAAQMLAAIkHaQInHdAAKiQAAKjonHZQokHesLAAQsKAAooneg");
	var mask_graphics_88 = new cjs.Graphics().p("AvrTgQo1nlAAqyQAAqyI1noQI4nlMjAAQMkAAI1HlQI5HoAAKyQAAKyo5HlQo1HpskAAQsjAAo4npg");
	var mask_graphics_89 = new cjs.Graphics().p("AwzToQpGnwAArCQAArBJGn0QJKnwM8AAQM8AAJGHwQJKH0AALBQAALCpKHwQpGH0s8AAQs8AApKn0g");
	var mask_graphics_90 = new cjs.Graphics().p("Ax7TwQpXn7AArSQAArRJXn+QJcn7NUAAQNVAAJYH7QJbH+AALRQAALSpbH7QpYH+tVAAQtUAApcn+g");
	var mask_graphics_91 = new cjs.Graphics().p("AzDT4QpooHAArhQAArgJooKQJtoGNtAAQNuAAJpIGQJtIKAALgQAALhptIHQppIJtuAAQttAAptoJg");
	var mask_graphics_92 = new cjs.Graphics().p("A0KUCQp6oRAArxQAArwJ6oVQJ+oROFAAQOHAAJ6IRQJ+IVAALwQAALxp+IRQp6IVuHAAQuFAAp+oVg");
	var mask_graphics_93 = new cjs.Graphics().p("A1SUdQqLocAAsBQAAsAKLogQKQocOeAAQOfAAKLIcQKQIgAAMAQAAMBqQIcQqLIgufAAQueAAqQogg");
	var mask_graphics_94 = new cjs.Graphics().p("A2aU4QqconAAsRQAAsQKcoqQKionO2AAQO4AAKcInQKiIqAAMQQAAMRqiInQqcIqu4AAQu2AAqioqg");
	var mask_graphics_95 = new cjs.Graphics().p("A3hVSQquoyAAsgQAAsfKuo2QKyoyPQAAQPQAAKuIyQKyI2AAMfQAAMgqyIyQquI2vQAAQvQAAqyo2g");
	var mask_graphics_96 = new cjs.Graphics().p("A4pVtQq/o9AAswQAAsvK/pBQLEo9PoAAQPpAAK/I9QLEJBAAMvQAAMwrEI9Qq/JBvpAAQvoAArEpBg");
	var mask_graphics_97 = new cjs.Graphics().p("A5wWIQrRpIAAtAQAAs/LRpMQLVpIQAAAQQCAALQJIQLWJMAAM/QAANArWJIQrQJMwCAAQwAAArVpMg");
	var mask_graphics_98 = new cjs.Graphics().p("A65WiQrhpTAAtPQAAtOLhpYQLnpTQZAAQQbAALhJTQLnJYAANOQAANPrnJTQrhJYwbAAQwZAArnpYg");
	var mask_graphics_99 = new cjs.Graphics().p("A8AW9QrzpeAAtfQAAteLzpiQL4peQyAAQQzAALzJeQL4JiAANeQAANfr4JeQrzJiwzAAQwyAAr4pig");
	var mask_graphics_100 = new cjs.Graphics().p("A9IXYQsEppAAtvQAAtuMEptQMKppRKAAQRMAAMEJpQMKJtAANuQAANvsKJpQsEJtxMAAQxKAAsKptg");
	var mask_graphics_101 = new cjs.Graphics().p("A9+XyQsWp0AAt+QAAt9MWp5QMbp0RjAAQRkAAMWJ0QMbJ5AAN9QAAN+sbJ0QsWJ5xkAAQxjAAsbp5g");
	var mask_graphics_102 = new cjs.Graphics().p("A+oYNQsnp/AAuOQAAuNMnqEQMsp/R8AAQR9AAMnJ/QMsKEAAONQAAOOssJ/QsnKEx9AAQx8AAssqEg");
	var mask_graphics_103 = new cjs.Graphics().p("A/SYoQs4qKAAueQAAudM4qOQM+qLSUAAQSVAAM4KLQM+KOAAOdQAAOes+KKQs4KPyVAAQyUAAs+qPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-31.15,y:29.95}).wait(1).to({graphics:mask_graphics_1,x:-19.8523,y:30.1102}).wait(1).to({graphics:mask_graphics_2,x:-2.1041,y:30.2704}).wait(1).to({graphics:mask_graphics_3,x:15.6936,y:30.4055}).wait(1).to({graphics:mask_graphics_4,x:29.9417,y:30.5657}).wait(1).to({graphics:mask_graphics_5,x:39.0645,y:30.7009}).wait(1).to({graphics:mask_graphics_6,x:48.1626,y:30.8361}).wait(1).to({graphics:mask_graphics_7,x:57.2604,y:31.0213}).wait(1).to({graphics:mask_graphics_8,x:66.3835,y:31.1815}).wait(1).to({graphics:mask_graphics_9,x:75.4812,y:31.2916}).wait(1).to({graphics:mask_graphics_10,x:85.1544,y:31.4518}).wait(1).to({graphics:mask_graphics_11,x:94.8275,y:31.612}).wait(1).to({graphics:mask_graphics_12,x:104.4502,y:31.7472}).wait(1).to({graphics:mask_graphics_13,x:114.1484,y:31.9324}).wait(1).to({graphics:mask_graphics_14,x:123.7711,y:32.0676}).wait(1).to({graphics:mask_graphics_15,x:133.4692,y:32.2277}).wait(1).to({graphics:mask_graphics_16,x:143.117,y:32.3883}).wait(1).to({graphics:mask_graphics_17,x:152.7651,y:32.5235}).wait(1).to({graphics:mask_graphics_18,x:162.4379,y:32.6837}).wait(1).to({graphics:mask_graphics_19,x:172.111,y:32.8688}).wait(1).to({graphics:mask_graphics_20,x:182.8841,y:33.004}).wait(1).to({graphics:mask_graphics_21,x:193.6569,y:33.1642}).wait(1).to({graphics:mask_graphics_22,x:204.43,y:33.3244}).wait(1).to({graphics:mask_graphics_23,x:215.2277,y:33.4596}).wait(1).to({graphics:mask_graphics_24,x:226.0009,y:33.6197}).wait(1).to({graphics:mask_graphics_25,x:236.7736,y:33.7549}).wait(1).to({graphics:mask_graphics_26,x:247.5717,y:33.9401}).wait(1).to({graphics:mask_graphics_27,x:258.3445,y:34.1003}).wait(1).to({graphics:mask_graphics_28,x:269.1176,y:34.2355}).wait(1).to({graphics:mask_graphics_29,x:279.9157,y:34.3957}).wait(1).to({graphics:mask_graphics_30,x:273.4135,y:35.5808}).wait(1).to({graphics:mask_graphics_31,x:266.8866,y:36.7664}).wait(1).to({graphics:mask_graphics_32,x:260.3843,y:37.9766}).wait(1).to({graphics:mask_graphics_33,x:253.9075,y:39.1868}).wait(1).to({graphics:mask_graphics_34,x:247.3802,y:40.3719}).wait(1).to({graphics:mask_graphics_35,x:240.9033,y:41.5571}).wait(1).to({graphics:mask_graphics_36,x:234.3511,y:42.7423}).wait(1).to({graphics:mask_graphics_37,x:227.8492,y:43.9275}).wait(1).to({graphics:mask_graphics_38,x:221.3723,y:45.1627}).wait(1).to({graphics:mask_graphics_39,x:214.8451,y:46.3479}).wait(1).to({graphics:mask_graphics_40,x:208.3682,y:47.533}).wait(1).to({graphics:mask_graphics_41,x:201.866,y:48.7432}).wait(1).to({graphics:mask_graphics_42,x:195.3391,y:49.9034}).wait(1).to({graphics:mask_graphics_43,x:188.8368,y:51.1136}).wait(1).to({graphics:mask_graphics_44,x:182.335,y:52.3238}).wait(1).to({graphics:mask_graphics_45,x:175.8327,y:53.509}).wait(1).to({graphics:mask_graphics_46,x:169.3308,y:54.7195}).wait(1).to({graphics:mask_graphics_47,x:162.8039,y:55.8797}).wait(1).to({graphics:mask_graphics_48,x:156.3267,y:57.0899}).wait(1).to({graphics:mask_graphics_49,x:149.8248,y:58.3001}).wait(1).to({graphics:mask_graphics_50,x:151.3858,y:61.8432}).wait(1).to({graphics:mask_graphics_51,x:152.9718,y:65.3864}).wait(1).to({graphics:mask_graphics_52,x:154.5328,y:68.9795}).wait(1).to({graphics:mask_graphics_53,x:156.0938,y:72.5227}).wait(1).to({graphics:mask_graphics_54,x:157.6547,y:76.0912}).wait(1).to({graphics:mask_graphics_55,x:159.2407,y:79.6343}).wait(1).to({graphics:mask_graphics_56,x:160.8017,y:83.1775}).wait(1).to({graphics:mask_graphics_57,x:162.3877,y:86.7456}).wait(1).to({graphics:mask_graphics_58,x:163.9237,y:90.2888}).wait(1).to({graphics:mask_graphics_59,x:165.4846,y:93.8323}).wait(1).to({graphics:mask_graphics_60,x:167.0456,y:97.4255}).wait(1).to({graphics:mask_graphics_61,x:168.6316,y:100.9686}).wait(1).to({graphics:mask_graphics_62,x:170.193,y:104.5368}).wait(1).to({graphics:mask_graphics_63,x:171.7789,y:108.0799}).wait(1).to({graphics:mask_graphics_64,x:173.3149,y:111.6234}).wait(1).to({graphics:mask_graphics_65,x:174.9009,y:115.1916}).wait(1).to({graphics:mask_graphics_66,x:176.4619,y:118.7347}).wait(1).to({graphics:mask_graphics_67,x:178.0479,y:122.3029}).wait(1).to({graphics:mask_graphics_68,x:179.6089,y:125.846}).wait(1).to({graphics:mask_graphics_69,x:181.1698,y:129.4146}).wait(1).to({graphics:mask_graphics_70,x:182.7308,y:132.9827}).wait(1).to({graphics:mask_graphics_71,x:184.3168,y:136.5259}).wait(1).to({graphics:mask_graphics_72,x:185.8778,y:140.094}).wait(1).to({graphics:mask_graphics_73,x:187.4638,y:143.6372}).wait(1).to({graphics:mask_graphics_74,x:189.0247,y:147.2053}).wait(1).to({graphics:mask_graphics_75,x:192.0082,y:149.084}).wait(1).to({graphics:mask_graphics_76,x:194.9662,y:151.0124}).wait(1).to({graphics:mask_graphics_77,x:197.9492,y:152.8907}).wait(1).to({graphics:mask_graphics_78,x:200.9073,y:154.7695}).wait(1).to({graphics:mask_graphics_79,x:203.8657,y:156.6728}).wait(1).to({graphics:mask_graphics_80,x:206.8487,y:158.5511}).wait(1).to({graphics:mask_graphics_81,x:209.7817,y:160.4299}).wait(1).to({graphics:mask_graphics_82,x:212.7648,y:162.3332}).wait(1).to({graphics:mask_graphics_83,x:215.7482,y:164.2115}).wait(1).to({graphics:mask_graphics_84,x:218.6812,y:166.1153}).wait(1).to({graphics:mask_graphics_85,x:221.6643,y:167.9936}).wait(1).to({graphics:mask_graphics_86,x:224.6473,y:169.8973}).wait(1).to({graphics:mask_graphics_87,x:227.6057,y:171.7757}).wait(1).to({graphics:mask_graphics_88,x:230.5637,y:173.654}).wait(1).to({graphics:mask_graphics_89,x:233.5468,y:175.5577}).wait(1).to({graphics:mask_graphics_90,x:236.5052,y:177.4361}).wait(1).to({graphics:mask_graphics_91,x:239.4632,y:179.3144}).wait(1).to({graphics:mask_graphics_92,x:242.4213,y:181.0431}).wait(1).to({graphics:mask_graphics_93,x:245.4043,y:181.0215}).wait(1).to({graphics:mask_graphics_94,x:248.3627,y:180.9998}).wait(1).to({graphics:mask_graphics_95,x:251.3207,y:180.9786}).wait(1).to({graphics:mask_graphics_96,x:254.3038,y:181.0069}).wait(1).to({graphics:mask_graphics_97,x:257.2868,y:180.9852}).wait(1).to({graphics:mask_graphics_98,x:260.2202,y:180.964}).wait(1).to({graphics:mask_graphics_99,x:263.2033,y:180.9923}).wait(1).to({graphics:mask_graphics_100,x:266.1863,y:181.0206}).wait(1).to({graphics:mask_graphics_101,x:267.4193,y:180.9994}).wait(1).to({graphics:mask_graphics_102,x:267.4527,y:181.0277}).wait(1).to({graphics:mask_graphics_103,x:267.4358,y:181.006}).wait(105));

	// title_page
	this.instance = new lib.Heart();
	this.instance.setTransform(273.75,356.3,0.8186,0.7209,0,0,0,-1.7,1.8);

	this.instance_1 = new lib.CachedBmp_11();
	this.instance_1.setTransform(360.6,337.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_10();
	this.instance_2.setTransform(55.8,337.05,0.5,0.5);

	this.instance_3 = new lib.DefaultButton();
	this.instance_3.setTransform(424.55,359.7,0.5333,0.4003,0,0,0,0.2,0);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_4 = new lib.DefaultButton();
	this.instance_4.setTransform(124.5,359.7,0.5333,0.4003,0,0,0,0.2,0);
	new cjs.ButtonHelper(this.instance_4, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.text = new cjs.Text("5", "22px 'MV Boli'", "#FFFF00");
	this.text.textAlign = "center";
	this.text.lineHeight = 37;
	this.text.lineWidth = 29;
	this.text.parent = this;
	this.text.setTransform(214.6,283.25);

	this.text_1 = new cjs.Text("5", "22px 'MV Boli'", "#FFFF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 37;
	this.text_1.lineWidth = 29;
	this.text_1.parent = this;
	this.text_1.setTransform(214.6,253.25);

	this.text_2 = new cjs.Text("5", "22px 'MV Boli'", "#FFFF00");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 37;
	this.text_2.lineWidth = 29;
	this.text_2.parent = this;
	this.text_2.setTransform(214.6,222.85);

	this.instance_5 = new lib.CachedBmp_9();
	this.instance_5.setTransform(-55.9,281.25,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_8();
	this.instance_6.setTransform(-55.9,251.25,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_7();
	this.instance_7.setTransform(-55.9,220.85,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_6();
	this.instance_8.setTransform(16.5,181.4,0.5,0.5);

	this.instance_9 = new lib.PlayerStickman();
	this.instance_9.setTransform(424.05,239.5,0.7685,0.4591,0,0,0,-0.8,-0.1);

	this.text_3 = new cjs.Text("Player Name", "22px 'MV Boli'", "#FFFF00");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 37;
	this.text_3.lineWidth = 146;
	this.text_3.parent = this;
	this.text_3.setTransform(422.5,143.95);

	this.instance_10 = new lib.CachedBmp_5();
	this.instance_10.setTransform(76.6,72.35,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_4();
	this.instance_11.setTransform(35.7,131.95,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_3();
	this.instance_12.setTransform(-3.5,10.4,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_2();
	this.instance_13.setTransform(-3.5,10.4,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_12();
	this.instance_14.setTransform(19.25,127.6,0.5,0.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.text,this.text_1,this.text_2,this.instance_5,this.instance_6,this.instance_7,this.instance_8,this.instance_9,this.text_3,this.instance_10,this.instance_11,this.instance_12,this.instance_13,this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.text_3},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[]},104).wait(104));

	// actions
	this.HPOut = new cjs.Text("Hp", "22px 'MV Boli'");
	this.HPOut.name = "HPOut";
	this.HPOut.textAlign = "center";
	this.HPOut.lineHeight = 37;
	this.HPOut.lineWidth = 100;
	this.HPOut.parent = this;
	this.HPOut.setTransform(36.3,95.9);
	this.HPOut._off = true;

	this.timeline.addTween(cjs.Tween.get(this.HPOut).wait(118).to({_off:false},0).to({_off:true},5).wait(85));

	// main
	this.instance_15 = new lib.CachedBmp_22();
	this.instance_15.setTransform(-420.15,90.55,0.5,0.5);

	this.playerOut = new cjs.Text("Player Name", "22px 'MV Boli'", "#FFFF00");
	this.playerOut.name = "playerOut";
	this.playerOut.textAlign = "center";
	this.playerOut.lineHeight = 37;
	this.playerOut.lineWidth = 189;
	this.playerOut.parent = this;
	this.playerOut.setTransform(419.4,145.7);

	this.heartsOut = new cjs.Text("3", "22px 'MV Boli'");
	this.heartsOut.name = "heartsOut";
	this.heartsOut.textAlign = "center";
	this.heartsOut.lineHeight = 37;
	this.heartsOut.lineWidth = 27;
	this.heartsOut.parent = this;
	this.heartsOut.setTransform(273.75,350.45);

	this.instance_16 = new lib.Heart();
	this.instance_16.setTransform(273.75,358.05,0.8186,0.7209,0,0,0,-1.7,1.8);

	this.instance_17 = new lib.CachedBmp_21();
	this.instance_17.setTransform(360.6,338.8,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_20();
	this.instance_18.setTransform(55.8,338.8,0.5,0.5);

	this.startGame_btn = new lib.DefaultButton();
	this.startGame_btn.name = "startGame_btn";
	this.startGame_btn.setTransform(424.55,361.45,0.5333,0.4003,0,0,0,0.2,0);
	new cjs.ButtonHelper(this.startGame_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.randomizeStats_btn = new lib.DefaultButton();
	this.randomizeStats_btn.name = "randomizeStats_btn";
	this.randomizeStats_btn.setTransform(124.5,361.45,0.5333,0.4003,0,0,0,0.2,0);
	new cjs.ButtonHelper(this.randomizeStats_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.dexOut = new cjs.Text("5", "22px 'MV Boli'", "#FFFF00");
	this.dexOut.name = "dexOut";
	this.dexOut.textAlign = "center";
	this.dexOut.lineHeight = 37;
	this.dexOut.lineWidth = 29;
	this.dexOut.parent = this;
	this.dexOut.setTransform(214.6,285);

	this.strOut = new cjs.Text("5", "22px 'MV Boli'", "#FFFF00");
	this.strOut.name = "strOut";
	this.strOut.textAlign = "center";
	this.strOut.lineHeight = 37;
	this.strOut.lineWidth = 29;
	this.strOut.parent = this;
	this.strOut.setTransform(214.6,255);

	this.intOut = new cjs.Text("5", "22px 'MV Boli'", "#FFFF00");
	this.intOut.name = "intOut";
	this.intOut.textAlign = "center";
	this.intOut.lineHeight = 37;
	this.intOut.lineWidth = 29;
	this.intOut.parent = this;
	this.intOut.setTransform(214.6,224.6);

	this.instance_19 = new lib.CachedBmp_19();
	this.instance_19.setTransform(-55.9,283,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_18();
	this.instance_20.setTransform(-55.9,253,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_17();
	this.instance_21.setTransform(-55.9,222.6,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_16();
	this.instance_22.setTransform(16.5,183.15,0.5,0.5);

	this.instance_23 = new lib.PlayerStickman();
	this.instance_23.setTransform(424.05,241.25,0.7685,0.4591,0,0,0,-0.8,-0.1);

	this.instance_24 = new lib.CachedBmp_15();
	this.instance_24.setTransform(76.6,74.1,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_14();
	this.instance_25.setTransform(35.7,133.7,0.5,0.5);

	this.nameInput = new lib.an_TextInput({'id': 'nameInput', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.nameInput.name = "nameInput";
	this.nameInput.setTransform(173.95,154.85,1,1,0,0,0,50,11);

	this.instance_26 = new lib.CachedBmp_13();
	this.instance_26.setTransform(-3.5,12.15,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_12();
	this.instance_27.setTransform(19.25,129.35,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_26();
	this.instance_28.setTransform(220.15,321.65,0.5,0.5);

	this.continue_btn = new lib.DefaultButton();
	this.continue_btn.name = "continue_btn";
	this.continue_btn.setTransform(280.9,349.65,0.6873,0.472);
	new cjs.ButtonHelper(this.continue_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_29 = new lib.CachedBmp_25();
	this.instance_29.setTransform(53.55,239.7,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_24();
	this.instance_30.setTransform(61.95,82.7,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_23();
	this.instance_31.setTransform(1,24.35,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_29();
	this.instance_32.setTransform(426.7,346.1,0.5,0.5);

	this.begin_btn = new lib.DefaultButton();
	this.begin_btn.name = "begin_btn";
	this.begin_btn.setTransform(480.1,365.45,0.4128,0.4178,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.begin_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_33 = new lib.CachedBmp_28();
	this.instance_33.setTransform(3.1,11.6,0.5,0.5);

	this.instance_34 = new lib.CloudsMoving();
	this.instance_34.setTransform(363.85,159.9,1,1,0,0,0,173.6,91.4);

	this.instance_35 = new lib.Flowey();
	this.instance_35.setTransform(413.35,321.65,0.41,0.3292,0,0,0,1.9,-39.1);

	this.instance_36 = new lib.Flowey();
	this.instance_36.setTransform(323.4,332.1,0.41,0.3292,0,0,0,1.9,-39.1);

	this.instance_37 = new lib.Flowey();
	this.instance_37.setTransform(212.05,332.1,0.41,0.3292,0,0,0,1.9,-39.1);

	this.instance_38 = new lib.CachedBmp_27();
	this.instance_38.setTransform(-41.25,76.5,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_34();
	this.instance_39.setTransform(186.95,343.05,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_33();
	this.instance_40.setTransform(249.7,298.6,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_32();
	this.instance_41.setTransform(30.55,329.7,0.5,0.5);

	this.roll_btn = new lib.DefaultButton();
	this.roll_btn.name = "roll_btn";
	this.roll_btn.setTransform(91.1,358.1,0.4802,0.4541);
	new cjs.ButtonHelper(this.roll_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_42 = new lib.Bandit();
	this.instance_42.setTransform(476.6,189.6,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_43 = new lib.Bandit();
	this.instance_43.setTransform(424.8,171.05,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_44 = new lib.Bandit();
	this.instance_44.setTransform(510,147.15,0.7352,0.6833,0,0,0,-1.8,-20.8);

	this.instance_45 = new lib.CachedBmp_31();
	this.instance_45.setTransform(1.15,16.95,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_30();
	this.instance_46.setTransform(-6.9,165.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_27},{t:this.instance_26},{t:this.nameInput},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23,p:{regY:-0.1,scaleX:0.7685,scaleY:0.4591,x:424.05,y:241.25,regX:-0.8}},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.intOut},{t:this.strOut},{t:this.dexOut},{t:this.randomizeStats_btn},{t:this.startGame_btn},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16,p:{x:273.75,y:358.05}},{t:this.heartsOut},{t:this.playerOut,p:{x:419.4,y:145.7,text:"Player Name",font:"22px 'MV Boli'",color:"#FFFF00",lineHeight:37.45,lineWidth:189}},{t:this.instance_15}]},104).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.continue_btn},{t:this.instance_28}]},4).to({state:[{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_23,p:{regY:-0.2,scaleX:0.8924,scaleY:0.48,x:76.85,y:311.95,regX:-0.8}},{t:this.begin_btn},{t:this.instance_32}]},5).to({state:[{t:this.instance_46},{t:this.instance_45},{t:this.instance_23,p:{regY:-0.2,scaleX:0.552,scaleY:0.4227,x:37.2,y:186.8,regX:-0.9}},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.roll_btn},{t:this.instance_41},{t:this.playerOut,p:{x:-78,y:40.55,text:"Good Roll:\n You attack first, 1 math question\n\nBad Roll:\nYou defend their attacks, then you get to attack",font:"15px 'MV Boli'",color:"#990000",lineHeight:26.2,lineWidth:100}},{t:this.instance_16,p:{x:37.15,y:103.65}},{t:this.instance_40},{t:this.instance_39}]},5).to({state:[]},5).wait(85));

	// possibilites
	this.instance_47 = new lib.CachedBmp_40();
	this.instance_47.setTransform(-389.55,53.1,0.5,0.5);

	this.numTwoOut = new cjs.Text("Num", "28px 'MV Boli'");
	this.numTwoOut.name = "numTwoOut";
	this.numTwoOut.textAlign = "center";
	this.numTwoOut.lineHeight = 47;
	this.numTwoOut.lineWidth = 100;
	this.numTwoOut.parent = this;
	this.numTwoOut.setTransform(238.25,198.1);

	this.numOneOut = new cjs.Text("Num", "28px 'MV Boli'");
	this.numOneOut.name = "numOneOut";
	this.numOneOut.textAlign = "center";
	this.numOneOut.lineHeight = 47;
	this.numOneOut.lineWidth = 100;
	this.numOneOut.parent = this;
	this.numOneOut.setTransform(56.1,198.1);

	this.answerInput = new lib.an_TextInput({'id': 'answerInput', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.answerInput.name = "answerInput";
	this.answerInput.setTransform(449.05,209.7,1.478,2.3091,0,0,0,50.1,11);

	this.instance_48 = new lib.CachedBmp_39();
	this.instance_48.setTransform(132.05,158.65,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_38();
	this.instance_49.setTransform(308.7,158.65,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_37();
	this.instance_50.setTransform(212.15,310.65,0.5,0.5);

	this.proceed_btn = new lib.DefaultButton();
	this.proceed_btn.name = "proceed_btn";
	this.proceed_btn.setTransform(269.75,336.8,0.5899,0.5644,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.proceed_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_51 = new lib.CachedBmp_36();
	this.instance_51.setTransform(0,0,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_35();
	this.instance_52.setTransform(21.85,149.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_52},{t:this.instance_51},{t:this.proceed_btn},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.answerInput},{t:this.numOneOut},{t:this.numTwoOut},{t:this.instance_47}]},123).to({state:[]},5).wait(80));

	// control
	this.hpOut = new cjs.Text("hp", "22px 'MV Boli'");
	this.hpOut.name = "hpOut";
	this.hpOut.textAlign = "center";
	this.hpOut.lineHeight = 37;
	this.hpOut.lineWidth = 100;
	this.hpOut.parent = this;
	this.hpOut.setTransform(39.65,91.05);
	this.hpOut._off = true;

	this.timeline.addTween(cjs.Tween.get(this.hpOut).wait(128).to({_off:false},0).to({_off:true},25).wait(55));

	// banditsDefend
	this.instance_53 = new lib._3Bandits();
	this.instance_53.setTransform(462.4,160.3,1,1,0,0,0,81.7,86.2);
	this.instance_53._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_53).wait(128).to({_off:false},0).wait(1).to({rotation:-1.1538,x:448.7,y:141.4},0).wait(1).to({rotation:-2.3075,x:434.65,y:125.35},0).wait(1).to({rotation:-3.4613,x:420.35,y:112.1},0).wait(1).to({rotation:-4.615,x:405.75,y:101.65},0).wait(1).to({rotation:-5.7688,x:390.8,y:94.05},0).wait(1).to({rotation:-6.9226,x:375.55,y:89.2},0).wait(1).to({rotation:-8.0763,x:359.95,y:87.2},0).wait(1).to({rotation:-9.2301,x:344.1,y:88.05},0).wait(1).to({rotation:-10.3839,x:327.85,y:91.65},0).wait(1).to({rotation:-11.5376,x:311.3,y:98.05},0).wait(1).to({rotation:-12.6914,x:294.45,y:107.35},0).wait(1).to({rotation:-13.8451,x:277.3,y:119.4},0).wait(1).to({rotation:-14.9989,x:259.75,y:134.25},0).wait(1).to({rotation:-10.908,x:275.75,y:130.25},0).wait(1).to({rotation:-6.8172,x:291.2,y:126.7},0).wait(1).to({rotation:-2.7263,x:306.15,y:123.6},0).wait(1).to({rotation:1.3645,x:320.6,y:121.1},0).wait(1).to({rotation:5.4554,x:334.35,y:119.05},0).wait(1).to({rotation:9.5462,x:347.3,y:117.75},0).wait(1).to({rotation:13.6371,x:359.4,y:117.35},0).wait(1).to({rotation:17.7279,x:370.05,y:118.25},0).wait(1).to({rotation:21.8188,x:378.75,y:120.9},0).wait(1).to({rotation:25.9096,x:383.5,y:127.3},0).wait(1).to({rotation:30.0005,x:364.75,y:155.25},0).to({_off:true},1).wait(55));

	// defPath
	this.instance_54 = new lib.CachedBmp_44();
	this.instance_54.setTransform(5.75,286.15,0.5,0.5);

	this.instance_55 = new lib.Heart();
	this.instance_55.setTransform(38.15,98.8,0.8186,0.7209,0,0,0,-1.7,1.8);

	this.instance_56 = new lib.CachedBmp_43();
	this.instance_56.setTransform(207.1,324.85,0.5,0.5);

	this.attack_btn = new lib.DefaultButton();
	this.attack_btn.name = "attack_btn";
	this.attack_btn.setTransform(254.45,353.25,0.4802,0.4541);
	new cjs.ButtonHelper(this.attack_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_57 = new lib.PlayerStickman();
	this.instance_57.setTransform(38.2,181.95,0.552,0.4227,0,0,0,-0.9,-0.2);

	this.instance_58 = new lib.CachedBmp_42();
	this.instance_58.setTransform(2.15,12.1,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_41();
	this.instance_59.setTransform(-5.9,133.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.attack_btn},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54}]},128).to({state:[]},25).wait(55));

	// playerAtks
	this.instance_60 = new lib.Symbol1();
	this.instance_60.setTransform(41.95,154.3,1,1,0,0,0,52,81.2);
	this.instance_60._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_60).wait(153).to({_off:false},0).wait(1).to({regX:50.5,regY:96.1,rotation:0.6533,x:48.3,y:169.7},0).wait(1).to({rotation:1.3066,x:56.1,y:170.2},0).wait(1).to({rotation:1.96,x:63.85,y:170.75},0).wait(1).to({rotation:2.6133,x:71.7,y:171.2},0).wait(1).to({rotation:3.2666,x:79.5,y:171.75},0).wait(1).to({rotation:3.9199,x:87.4,y:172.2},0).wait(1).to({rotation:4.5732,x:95.2,y:172.75},0).wait(1).to({rotation:5.2266,x:103.05,y:173.25},0).wait(1).to({rotation:5.8799,x:110.85,y:173.7},0).wait(1).to({rotation:6.5332,x:118.65,y:174.25},0).wait(1).to({rotation:7.1865,x:126.5,y:174.7},0).wait(1).to({rotation:7.8398,x:134.35,y:175.25},0).wait(1).to({rotation:8.4932,x:142.15,y:175.7},0).wait(1).to({rotation:9.1465,x:149.95,y:176.25},0).wait(1).to({rotation:9.7998,x:157.8,y:176.7},0).wait(1).to({rotation:10.4531,x:167.65,y:168.55},0).wait(1).to({rotation:11.1065,x:177.55,y:160.4},0).wait(1).to({rotation:11.7598,x:187.45,y:152.25},0).wait(1).to({rotation:12.4131,x:197.3,y:144.05},0).wait(1).to({rotation:13.0664,x:207.2,y:135.85},0).wait(1).to({rotation:13.7197,x:217.1,y:127.75},0).wait(1).to({rotation:14.3731,x:226.95,y:119.6},0).wait(1).to({rotation:15.0264,x:236.85,y:111.4},0).wait(1).to({rotation:15.6797,x:246.75,y:103.25},0).wait(1).to({rotation:16.333,x:256.6,y:95.1},0).wait(1).to({rotation:16.9863,x:267.45,y:98.65},0).wait(1).to({rotation:17.6397,x:278.25,y:102.25},0).wait(1).to({rotation:18.293,x:288.95,y:105.85},0).wait(1).to({rotation:18.9463,x:299.7,y:109.35},0).wait(1).to({rotation:19.5996,x:310.5,y:112.95},0).wait(1).to({rotation:20.2529,x:321.35,y:116.5},0).wait(1).to({rotation:20.9063,x:332.05,y:120},0).wait(1).to({rotation:21.5596,x:342.85,y:123.65},0).wait(1).to({rotation:22.2129,x:353.6,y:127.2},0).wait(1).to({rotation:20.0403,x:353.35,y:130.9},0).wait(1).to({rotation:17.8677,x:353.05,y:134.55},0).wait(1).to({rotation:15.6951,x:352.75,y:138.2},0).wait(1).to({rotation:13.5225,x:352.55,y:141.9},0).wait(1).to({rotation:11.3499,x:352.25,y:145.5},0).wait(1).to({rotation:9.1773,x:352,y:149.05},0).wait(1).to({rotation:7.0047,x:351.75,y:152.65},0).wait(1).to({rotation:4.8321,x:351.5,y:156.2},0).wait(1).to({rotation:2.6595,x:351.3,y:159.75},0).wait(1).to({rotation:0.487,x:351.05,y:163.3},0).to({_off:true},1).wait(10));

	// banditsDie
	this.instance_61 = new lib.Other3Bandits();
	this.instance_61.setTransform(467.9,171.1,1,1,0,0,0,81.7,98);
	this.instance_61._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_61).wait(153).to({_off:false},0).wait(1).to({rotation:0.4687,x:466.05,y:170.35},0).wait(1).to({rotation:0.9374,x:464.2,y:169.7},0).wait(1).to({rotation:1.4061,x:462.35,y:169},0).wait(1).to({rotation:1.8749,x:460.5,y:168.3},0).wait(1).to({rotation:2.3436,x:458.7,y:167.6},0).wait(1).to({rotation:2.8123,x:456.8,y:166.95},0).wait(1).to({rotation:3.281,x:454.95,y:166.2},0).wait(1).to({rotation:3.7497,x:453.1,y:165.55},0).wait(1).to({rotation:4.2184,x:451.3,y:164.85},0).wait(1).to({rotation:4.6872,x:449.45,y:164.15},0).wait(1).to({rotation:5.1559,x:447.6,y:163.5},0).wait(1).to({rotation:5.6246,x:445.75,y:162.8},0).wait(1).to({rotation:6.0933,x:443.9,y:162.05},0).wait(1).to({rotation:6.562,x:442.05,y:161.4},0).wait(1).to({rotation:7.0307,x:440.25,y:160.7},0).wait(1).to({rotation:7.4995,x:438.35,y:160},0).wait(1).to({rotation:7.9682,x:436.5,y:159.3},0).wait(1).to({rotation:8.4369,x:434.65,y:158.65},0).wait(1).to({rotation:8.9056,x:432.85,y:157.9},0).wait(1).to({rotation:9.3743,x:431,y:157.25},0).wait(1).to({rotation:9.843,x:429.15,y:156.55},0).wait(1).to({rotation:10.3117,x:427.35,y:155.8},0).wait(1).to({rotation:10.7805,x:425.45,y:155.15},0).wait(1).to({rotation:11.2492,x:429.2,y:155.3},0).wait(1).to({rotation:11.7179,x:432.85,y:155.4},0).wait(1).to({rotation:12.1866,x:436.55,y:155.55},0).wait(1).to({rotation:12.6553,x:440.25,y:155.65},0).wait(1).to({rotation:13.124,x:443.95,y:155.8},0).wait(1).to({rotation:13.5928,x:447.6,y:155.9},0).wait(1).to({rotation:14.0615,x:451.35,y:156.05},0).wait(1).to({rotation:14.5302,x:455.05,y:156.15},0).wait(1).to({rotation:14.9989,x:458.7,y:156.3},0).wait(1).to({rotation:21.2488,x:462.45,y:156.45},0).wait(1).to({rotation:27.4988,x:466.1,y:156.55},0).wait(1).to({rotation:33.7487,x:469.8,y:156.7},0).wait(1).to({rotation:39.9987,x:473.5,y:156.75},0).wait(1).to({rotation:46.2486,x:477.2,y:156.9},0).wait(1).to({rotation:52.4986,x:480.9,y:157},0).wait(1).to({rotation:58.7485,x:484.55,y:157.2},0).wait(1).to({rotation:64.9984,x:482.85,y:168.85},0).wait(1).to({rotation:71.2484,x:481.05,y:180.5},0).wait(1).to({rotation:77.4983,x:479.3,y:192.15},0).wait(1).to({rotation:83.7483,x:477.55,y:203.8},0).wait(1).to({rotation:89.9982,x:475.75,y:215.5},0).to({_off:true},1).wait(10));

	// atkPath
	this.instance_62 = new lib.CachedBmp_47();
	this.instance_62.setTransform(213.85,317.05,0.5,0.5);

	this.final_btn = new lib.VaultButton();
	this.final_btn.name = "final_btn";
	this.final_btn.setTransform(272.75,341.6,0.5938,0.4733);
	new cjs.ButtonHelper(this.final_btn, 0, 1, 2, false, new lib.VaultButton(), 3);

	this.instance_63 = new lib.CachedBmp_46();
	this.instance_63.setTransform(-10.05,12.1,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_45();
	this.instance_64.setTransform(-18.1,160.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_64},{t:this.instance_63},{t:this.final_btn},{t:this.instance_62}]},153).to({state:[]},45).wait(10));

	// vault
	this.instance_65 = new lib.CachedBmp_51();
	this.instance_65.setTransform(209.9,343.7,0.5,0.5);

	this.new_btn = new lib.DefaultButton();
	this.new_btn.name = "new_btn";
	this.new_btn.setTransform(251.75,366.4,0.3827,0.3891,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.new_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_66 = new lib.CachedBmp_50();
	this.instance_66.setTransform(7.05,150.6,0.5,0.5);

	this.instance_67 = new lib.Stash();
	this.instance_67.setTransform(475.8,306.2,0.72,0.6548,0,0,0,-0.8,-46.8);

	this.instance_68 = new lib.Stash();
	this.instance_68.setTransform(387.55,276.6,0.72,0.6548,0,0,0,-0.8,-46.8);

	this.instance_69 = new lib.Stash();
	this.instance_69.setTransform(462.95,244.35,0.72,0.6548,0,0,0,-0.8,-46.8);

	this.instance_70 = new lib.Stash();
	this.instance_70.setTransform(387.55,218.7,0.72,0.6548,0,0,0,-0.8,-46.8);

	this.instance_71 = new lib.Stash();
	this.instance_71.setTransform(453.35,177,0.72,0.6548,0,0,0,-0.8,-46.8);

	this.instance_72 = new lib.PlayerStickman();
	this.instance_72.setTransform(249.55,243.95,0.9277,0.5683,0,0,0,-0.7,-0.1);

	this.instance_73 = new lib.CachedBmp_49();
	this.instance_73.setTransform(2,0,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_48();
	this.instance_74.setTransform(9.05,136,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.new_btn},{t:this.instance_65}]},198).to({state:[]},5).wait(5));

	// defeat
	this.instance_75 = new lib.CachedBmp_54();
	this.instance_75.setTransform(233.95,328.7,0.5,0.5);

	this.retry_btn = new lib.DefaultButton();
	this.retry_btn.name = "retry_btn";
	this.retry_btn.setTransform(277,357.55,0.3487,0.3711);
	new cjs.ButtonHelper(this.retry_btn, 0, 1, 2, false, new lib.DefaultButton(), 3);

	this.instance_76 = new lib.PlayerStickman();
	this.instance_76.setTransform(261.05,271.45,0.9277,0.5683,-90,0,0,-0.8,-0.1);

	this.instance_77 = new lib.CachedBmp_53();
	this.instance_77.setTransform(0,8,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_52();
	this.instance_78.setTransform(103.1,160.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.retry_btn},{t:this.instance_75}]},203).wait(5));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-145.1,188.7,757.3000000000001,204.90000000000003);
// library properties:
lib.properties = {
	id: 'B85D0718C994E04D80CF0DF3E8834CB0',
	width: 550,
	height: 400,
	fps: 24,
	color: "#0000FF",
	opacity: 1.00,
	manifest: [
		{src:"images/demoB5_atlas_.png", id:"demoB5_atlas_"},
		{src:"images/demoB5_atlas_2.png", id:"demoB5_atlas_2"},
		{src:"images/demoB5_atlas_3.png", id:"demoB5_atlas_3"},
		{src:"images/demoB5_atlas_4.png", id:"demoB5_atlas_4"},
		{src:"images/demoB5_atlas_5.png", id:"demoB5_atlas_5"},
		{src:"images/demoB5_atlas_6.png", id:"demoB5_atlas_6"},
		{src:"images/demoB5_atlas_7.png", id:"demoB5_atlas_7"},
		{src:"sounds/fireworks.mp3", id:"fireworks"},
		{src:"https://code.jquery.com/jquery-3.4.1.min.js", id:"lib/jquery-3.4.1.min.js"},
		{src:"components/sdk/anwidget.js", id:"sdk/anwidget.js"},
		{src:"components/ui/src/textinput.js", id:"an.TextInput"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B85D0718C994E04D80CF0DF3E8834CB0'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
function _updateVisibility(evt) {
	if((this.stage == null || this._off || this._lastAddedFrame != this.parent.currentFrame) && this._element && this._element._attached) {
		this._element.detach();
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
	var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
	var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
	mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
	this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
	var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
	var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
	var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
	this._element.setProperty('transform', tx);
	this._element.setProperty('width', w);
	this._element.setProperty('height', h);
	this._element.update();
}

function _tick(evt) {
	this._lastAddedFrame = this.parent.currentFrame;
	var stage = this.stage;
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}
function _componentDraw(ctx) {
	if(this._element && !this._element._attached) {
		this._element.attach($('#dom_overlay_container'));
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;